<head>
    <!-- Document Meta-->
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <!-- IE Compatibility Meta-->
    <meta name="author" content="zytheme"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
    <meta name="description" content="Multi-purpose Business html5 landing page"/>
    <link rel="icon" href="assets/images/logo_icon.png" />
    <!--  Fonts-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500&amp;display=swap" rel="stylesheet" type="text/css"/>
    <!-- Stylesheets-->
    <link href="assets_/css/vendor.css" rel="stylesheet"/>
    <link href="assets_/css/style.css" rel="stylesheet"/>
    <!-- 
    Document Title
    ============================================= 
    -->
    <title>Fulhive Platform</title>
  </head>