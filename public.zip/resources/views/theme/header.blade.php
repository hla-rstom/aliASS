<header class="header header-transparent header-sticky">
        <nav class="navbar navbar-sticky navbar-expand-lg" id="primary-menu"> 
          <div class="container"> <a class="logo navbar-brand" href="/"><img class="logo logo-dark" src="asset/img/fulhive-logo-black.png" width="200px" alt="Logo"/><img width="200px" class="logo logo-light" src="asset/img/fulhive-logo-white.png" alt="Leland Logo"/></a>
            <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarContent" aria-expanded="false"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarContent">
              <ul class="navbar-nav ml-auto">
                <li class="nav-item active"><a class="nav-link" data-scroll="scrollTo" href="#hero">Home</a></li>
                
              </ul>
              <div class="module-container">
                <!--module-btn-->
                <div class="module module-cta"><a class="btn btn--white btn--arrows" href="https://forms.gle/7Q2KcoeH8iAZpWW78"> <span>Find Your Space <i class="icon-right-arrow"></i></span></a></div>
              </div>
              <!-- End Module Container  -->
            </div>
            <!-- End .nav-collapse-->
          </div>
          <!-- End .container-->
        </nav>
        <!-- End .navbar-->
      </header>