 <footer class="footer footer-5" id="footer">
        <div class="container">
          <div class="row">
            <div class="col-12 col-md-12 col-lg-12 text--center">
              <div class="footer--copyright"><span>2024 &copy; <a href="#">Fulhive Sdn Bhd - 202301037656 (1531579-H)</a>. All rights reserved.</span></div>
            </div>
          </div>
        </div>
</footer>