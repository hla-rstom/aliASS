@extends('layouts.master')

@section('content')
<!-- Begin Page Content -->
<div class="container-fluid">
    @include('partials._alert')
    @role('seller')
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
    </div>
    <div class="row">
        <!-- Area Chart -->
        <div class="col-xl-6 col-lg-7">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Wallet</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="mb-0"><span class="text-secondary">MYR.</span> {{$formattedBalance}}</h5>
                        <a href="{{ route('wallet_user')}}" class="btn btn-success btn-sm">Wallet</a>
                    </div>
                    <div class="d-flex justify-content-between align-items-center">
                        <small class="text-muted"> Pending Balance RM. {{$pendingBalance}}</small>
                        <a href="{{ route('history_reimburse')}}" class="btn btn-outline-primary btn-sm">History Reimburse</a>
                        <a href="{{ route('history_transaction')}}" class="btn btn-outline-success btn-sm">History Transaction</a>
                        <!-- <button class="btn btn-outline-success btn-sm"> Pending Balance</button> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endrole

@role('super_admin')
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Welcome {{ Auth::user()->name }}</h1>
</div>
<div class="row">
    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Sellers</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">{{$totalSeller}}</div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Warehouses</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">{{$totalWarehouse}}</div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-home fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
<div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Packaging Fee</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">{{$sumFulhivePackaging}}</div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Pending Requests Card Example -->
   <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Order Fee</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">{{$sumOrderFulhive}}</div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
@endrole

@role('retail')
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
</div>
<div class="row">
    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-4 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Renatl Revenue</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">MYR {{$rentalRevenue ?? 0}}</div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-dollar-sign fa-2x text-gray-400"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-4 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Retail Requests</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">MYR {{$retailRequests ?? 0}}</div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-truck fa-2x text-gray-400"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>


    {{--  <div class="col-xl-4 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Packaging Reimburse</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">MYR {{$packagingReimburse}}</div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-cube fa-2x text-gray-400"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>  --}}
</div>

<div class="row">

    <!-- Area Chart -->
    <div class="col-xl-6 col-lg-7">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Wallet</h6>
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0"><span class="text-secondary">MYR.</span> {{$formattedBalance}}</h5>
                    <a href="{{ route('wallet_user')}}" class="btn btn-success btn-sm">Wallet</a>
                </div>
                <div class="d-flex justify-content-between align-items-center">
                    <small class="text-muted"> Pending Balance MYR. {{$pendingBalance}}</small>
                    <a href="{{ route('history_transaction')}}" class="btn btn-outline-success btn-sm">History Transaction</a>
                </div>
                <hr>
                <div class="d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-warehouse fa-2x text-gray-400 mr-2"></i>
                        <div>
                            <div class="font-weight-bold text-primary">Retail Probation</div>
                            <div class="small text-muted">No Insurance</div>
                        </div>
                    </div>
                    <div>

                        <a href="{{ route('history_reimburse')}}" class="btn btn-outline-primary btn-sm">History Reimburse</a>
                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#reimburseModal">
                            Reimburse
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="reimburseModal" tabindex="-1" role="dialog" aria-labelledby="reimburseModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="reimburseModalLabel">Reimburse Form</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="reimburseForm" method="POST" action="{{ route('store_reimburse') }}">
                        @csrf
                        <div class="form-group">
                            <label for="seller_id">Seller</label>
                            <select class="form-control select2" id="seller_id" name="seller_id" required>
                                @foreach ($sellers as $seller)
                                <option value="{{ $seller->id }}">{{ $seller->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="amount">Amount</label>
                            <input type="text" class="form-control" id="amount" name="amount" required>
                        </div>
                        <div class="form-group">
                            <label for="description">Description</label>
                            <input type="text" class="form-control" id="description" name="description" required>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" form="reimburseForm">Submit</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Area Chart -->
    <div class="col-xl-6 col-lg-7">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Seller productivity</h6>
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-6 mb-4">
    <a href="{{ route('request') }}" class="text-decoration-none">
        <div class="card bg-primary text-white shadow">
            <div class="card-body">
                <h5 class="card-title">Retail Requests</h5>
                <div class="text-white-100 small">{{$done}}</div>
            </div>
        </div>
    </a>
</div>

                    <div class="col-lg-6 mb-4">
                        <div class="card bg-success text-white shadow">
                            <div class="card-body">
                                Package Completed
                                <div class="text-white-100 small">{{$done}}</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-4">
                        <div class="card bg-warning text-white shadow">
                            <div class="card-body">
                                Package Pending
                                <div class="text-white-100 small">{{$pending}}</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-4">
                        <div class="card bg-info text-white shadow">
                            <div class="card-body">
                                Package Sent
                                <div class="text-white-100 small">{{$sent}}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@endrole
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Select2 JS -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2({
            placeholder: "Select a seller",
            allowClear: true
        });
    });
</script>
@endsection