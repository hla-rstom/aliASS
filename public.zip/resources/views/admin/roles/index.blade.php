<style>
    .rounded-image {
        border-radius: 50%;
        /* Membuat sudut gambar menjadi lingkaran sempurna */
        width: 200px;
        /* Atur lebar gambar */
        height: 200px;
        /* Atur tinggi gambar - harus sama dengan lebar untuk lingkaran sempurna */
    }
</style>

@extends('layouts.master')

@section('content')
    <div class="container-fluid">
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        @if (session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert" id="success-alert">
                {{ session('success') }}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        @endif

        <h6 class="h3 mb-3 text-gray-800 ml-3">Role Managements</h6>

        <div class="col-lg-12">

            <button type="button" class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#addModal">
                <i class="fa fa-plus"></i>
                Add Role
            </button>

            <!-- Modal update-->
            <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addModalLabel">Add Role</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="{{ route('roleStore') }}" method="POST" enctype="multipart/form-data"
                                class="ml-3">
                                @csrf
                                <div class="row">
                                    <div class="form-group mr-3">
                                        <label for="exampleFormControlInput1">Name*</label>
                                        <input type="text" class="form-control" id="exampleFormControlInput1"
                                            name="name" value="">
                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <table class="table">
                <thead class="thead-light">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($roles as $role)
                        <tr>
                            <th scope="row">{{ $loop->iteration }}</th>
                            <td>{{ $role->name }}</td>
                            <td>
                                <div class="row">
                                    <button type="button" class="btn btn-outline-primary btn-sm" data-toggle="modal"
                                        data-target="#updateModal{{ $role->id }}"><i
                                            class="fas fa-solid fa-user-edit"></i></button>

                                    <!-- Modal update-->
                                    <div class="modal fade" id="updateModal{{ $role->id }}" tabindex="-1"
                                        aria-labelledby="updateModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="updateModalLabel">Update Role</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="{{ route('roleUpdate', $role->id) }}" method="POST"
                                                        enctype="multipart/form-data" class="ml-3">
                                                        @csrf
                                                        @method('put')
                                                        <div class="row">
                                                            <div class="form-group mr-3">
                                                                <label for="exampleFormControlInput1">Name*</label>
                                                                <input type="text" class="form-control"
                                                                    id="exampleFormControlInput1" name="name"
                                                                    value="{{ $role->name }}">
                                                            </div>
                                                        </div>

                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-dismiss="modal">Cancel</button>
                                                            <button type="submit" class="btn btn-primary">Save
                                                                changes</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Modal update -->

                                    <form action="{{ route('roleDelete', $role->id) }}" method="POST">
                                        @method('delete')
                                        @csrf
                                        <button type="submit" class="btn btn-outline-danger ml-2"
                                            onclick="return confirm('Are you sure you want to delete this record?')">
                                            <i class="fas fa-solid fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
@endsection
