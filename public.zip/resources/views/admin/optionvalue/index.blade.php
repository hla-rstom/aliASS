@extends('layouts.master')

@section('content')
<div class="container-fluid">
    @include('partials._alert')

    <h6 class="h3 mb-3 text-gray-800 ml-3">Option Value</h6>
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <!-- card tim saya -->
            <div class="col-lg-12">
                <div class="mb-4 mt-4">
                    <button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#addModal"><i class="fas fa-solid fa-plus"></i> Add Option Value</button>
                </div>
                <!-- Modal add-->
                <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="addModalLabel">Add Option Value</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="{{ route('optionvalue.store') }}" method="POST" enctype="multipart/form-data" class="ml-3">
                                    @csrf
                                    <div class="mb-3">
                                        <label class="small mb-1" for="option_id">Select Option <span class="text-danger">*</span></label>
                                        <select class="form-control form-control-solid @error('option_id') is-invalid @enderror" id="option_id" name="option_id">
                                            <option value="">Select an option</option>
                                            @foreach($options as $option)
                                                <option value="{{ $option->id }}" {{ old('option_id') == $option->id ? 'selected' : '' }}>
                                                    {{ $option->name }} <!-- Assuming 'name' is a field in your Option model -->
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('option_id')
                                            <div class="invalid-feedback">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>

                                    <div class="mb-3">
                                        <label class="small mb-1" for="value">Value <span class="text-danger">*</span></label>
                                        <input class="form-control form-control-solid @error('value') is-invalid @enderror" id="value" name="value" type="text" placeholder="Enter value" value="{{ old('value') }}" />
                                        @error('value')
                                            <div class="invalid-feedback">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Save changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Modal add -->
                <table class="table">
                    <thead class="thead-light">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>                            
                            <th scope="col">Description</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($optionvalues as $optionvalue)
                        <tr>
                            <th scope="row">{{ $loop->iteration  }}</th>
                            <td>{{ $optionvalue->option->name ?? '' }}</td>                            
                            <td> {{ $optionvalue->value ?? '' }}</td>
                            <td>
                                <div class="row">
                                    <button type="button" class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#updateModal{{$optionvalue->id}}"><i class="fas fa-solid fa-user-edit"></i></button>


                                    <div class="modal fade" id="updateModal{{$optionvalue->id}}" tabindex="-1" aria-labelledby="updateModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="updateModalLabel">Update optionvalue</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="{{ route('optionvalue.update', $optionvalue->id) }}" method="POST" enctype="multipart/form-data" class="ml-3">
                                                        @csrf
                                                        @method('put')
                                                        <div class="mb-3">
                                                            <label class="small mb-1" for="option_id">Select Option <span class="text-danger">*</span></label>
                                                            <select class="form-control form-control-solid @error('option_id') is-invalid @enderror" id="option_id" name="option_id">
                                                                <option value="">Select an option</option>
                                                                @foreach($options as $option)
                                                                    <option value="{{ $option->id }}" {{ old('option_id', $optionvalue->option_id) == $option->id ? 'selected' : '' }}>
                                                                        {{ $option->name }} <!-- Assuming 'name' is a field in your Option model -->
                                                                    </option>
                                                                @endforeach
                                                            </select>
                                                            @error('option_id')
                                                                <div class="invalid-feedback">
                                                                    {{ $message }}
                                                                </div>
                                                            @enderror
                                                        </div>

                                                        <div class="mb-3">
                                                            <label class="small mb-1" for="value">Value <span class="text-danger">*</span></label>
                                                            <input class="form-control form-control-solid @error('value') is-invalid @enderror" id="value" name="value" type="text" placeholder="Enter value" value="{{ old('value', $optionvalue->value) }}" />
                                                            @error('value')
                                                                <div class="invalid-feedback">
                                                                    {{ $message }}
                                                                </div>
                                                            @enderror
                                                        </div>
                                                            
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                            <button type="submit" class="btn btn-primary">Save changes</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <form action="{{ route('optionvalue.destroy', $optionvalue->id) }}" method="POST">
                                        @method('delete')
                                        @csrf
                                        <button type="submit" class="btn btn-outline-danger btn-sm ml-2" onclick="return confirm('Are you sure you want to delete this record?')">
                                            <i class="fas fa-solid fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                <div class="d-flex justify-content-end mt-4">

                    {!! $optionvalues->links() !!}
                </div>
            </div>
        </div>
        <!-- end card tim saya -->
    </div>
</div>
</div>
</div>
</div>

@endsection