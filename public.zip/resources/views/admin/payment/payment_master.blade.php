@extends('layouts.master')

@section('content')
<div class="container-fluid">
    @include('partials._alert')
    <div class="row justify-content-between">
        <h6 class="h3 mb-3 text-gray-800 ml-3">Payment Master</h6>
    </div>
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="mb-4 mt-4">
                    <button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#addModal"><i class="fas fa-solid fa-plus"></i> Add </button>
                </div>

                <!-- Modal add-->
                <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="addModalLabel">Add Bank</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="{{ route('storemasterpayment') }}" method="POST" enctype="multipart/form-data" class="ml-3">
                                    @csrf
                                    <div class="mb-3">
                                        <label class="small mb-1" for="description">Description</label>
                                        <input class="form-control form-control-solid @error('description') is-invalid @enderror" id="description" name="description" type="text" placeholder="" value="{{ old('description') }}" />
                                        @error('description')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                        @enderror
                                    </div>
                                    <div class="mb-3">
                                        <label class="small mb-1" for="percentage">Value</label>
                                        <input class="form-control form-control-solid @error('percentage') is-invalid @enderror" id="percentage" name="percentage" type="text" placeholder="" value="{{ old('percentage') }}" />
                                        @error('percentage')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                        @enderror
                                    </div>
                                    <div class="mb-3">
                                        <label class="small mb-1" for="symbol">Symbol</label>
                                        <select class="form-control form-control-solid @error('symbol') is-invalid @enderror" id="symbol" name="symbol">
                                            <option value="RM" {{ old('symbol') == 'RM' ? 'selected' : '' }}>RM</option>
                                            <option value="%" {{ old('symbol') == '%' ? 'selected' : '' }}>%</option>
                                        </select>
                                        @error('symbol')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                        @enderror
                                    </div>

                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Save changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-content col-md-12">
                    <table id="example" class="table table-borderless mt-4" style="width:100%">
                        <thead class="thead-light">
                            <tr>
                                <th>#</th>
                                <th>Description</th>
                                <th>Value</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if (!empty ($masterPayment))
                            @foreach ($masterPayment as $item)
                            <tr>
                                <td>{{$loop->iteration}}</td>
                                <td>{{$item->description}}</td>
                                @if ($item->symbol == 'RM')
                                <td>{{$item->symbol}} {{$item->percentage}}</td>
                                @else
                                <td> {{$item->percentage}} {{$item->symbol}}</td>
                                @endif
                                <td>
                                    <div class="row">
                                        <button type="button" class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#updateModal{{$item->id}}"><i class="fas fa-solid fa-user-edit"></i></button>


                                        <div class="modal fade" id="updateModal{{$item->id}}" tabindex="-1" aria-labelledby="updateModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="updateModalLabel">Update Category</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="{{ route('updatemasterpayment', $item->id) }}" method="POST" enctype="multipart/form-data" class="ml-3">
                                                            @csrf
                                                            @method('POST')
                                                            <div class="mb-3">
                                                                <label class="small mb-1" for="description">Description</label>
                                                                <input class="form-control form-control-solid @error('description') is-invalid @enderror" id="description" name="description" type="text" placeholder="" value="{{ old('description', $item->description) }}" />
                                                                @error('description')
                                                                <div class="invalid-feedback">
                                                                    {{ $message }}
                                                                </div>
                                                                @enderror
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="small mb-1" for="percentage">Value</label>
                                                                <input class="form-control form-control-solid @error('percentage') is-invalid @enderror" id="percentage" name="percentage" type="text" placeholder="" value="{{ old('percentage', $item->percentage) }}" />
                                                                @error('percentage')
                                                                <div class="invalid-feedback">
                                                                    {{ $message }}
                                                                </div>
                                                                @enderror
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="small mb-1" for="symbol">Symbol</label>
                                                                <select class="form-control form-control-solid @error('symbol') is-invalid @enderror" id="symbol" name="symbol">
                                                                    <option value="RM" {{ old('symbol', $item->symbol) == 'RM' ? 'selected' : '' }}>RM</option>
                                                                    <option value="%" {{ old('symbol', $item->symbol) == '%' ? 'selected' : '' }}>%</option>
                                                                </select>
                                                                @error('symbol')
                                                                <div class="invalid-feedback">
                                                                    {{ $message }}
                                                                </div>
                                                                @enderror
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                                <button type="submit" class="btn btn-primary">Update</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <form action="{{ route('deletemasterpayment', $item->id) }}" method="POST">
                                            @method('delete')
                                            @csrf
                                            <button type="submit" class="btn btn-outline-danger btn-sm ml-2" onclick="return confirm('Are you sure you want to delete this record?')">
                                                <i class="fas fa-solid fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

    });
</script>


@endsection