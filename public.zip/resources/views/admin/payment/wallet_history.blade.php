@extends('layouts.master')

@section('content')
<div class="container-fluid">
    @include('partials._alert')
    <div class="row justify-content-between">
        <h6 class="h3 mb-3 text-gray-800 ml-3">Wallet History</h6>
    </div>
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="tab-content col-md-12">
                    <table id="example" class="table table-borderless mt-4" style="width:100%">
                        <thead class="thead-light">
                            <tr>
                                <th>User</th>
                                <th>Date</th>
                                <th>Balance</th>
                                <th>Status</th>
                                <th>Type</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if (!empty ($walletHistory))
                            @foreach ($walletHistory as $item)
                            <tr>
                                <td>{{$item->user->name}} </td>
                                <td>{{$item->date}}</td>
                                <td>MYR {{$item->balance}}
                                    @if ($item->action === 'increment')
                                                    <div class="fa fa-arrow-up text-success"></div>
                                                    @else
                                                    <div class="fa fa-arrow-down text-danger"></div>
                                                    @endif
                                </td>
                                <td>{{$item->status}}</td>
                                <td>{{$item->type}}</td>
                            </tr>
                            @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

    });
</script>


@endsection
