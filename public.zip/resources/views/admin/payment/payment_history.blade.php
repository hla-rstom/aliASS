@extends('layouts.master')

@section('content')
<div class="container-fluid">
    @include('partials._alert')
    <div class="row justify-content-between">
        <h6 class="h3 mb-3 text-gray-800 ml-3">Payment History</h6>
    </div>
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="tab-content col-md-12">
                    <table id="example" class="table table-borderless mt-4" style="width:100%">
                        <thead class="thead-light">
                            <tr>
                                <th>Invoice</th>
                                <th>Date</th>
                                <th>Total Transaction</th>
                                <th>Total Amount</th>
                                <th>Warehouse Packaging Fee</th>
                                <th>Fulhive Packaging Fee</th>
                                <th>Warehouse Order Fee</th>
                                <th>Fulhive Order Fee</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if (!empty ($paymentHistory))
                            @foreach ($paymentHistory as $item)
                            <tr>
                                <td>{{$item->transaction->invoice_code ??''}}</td>
                                <td>{{$item->created_at}}</td>
                                <td>{{$item->transaction->currency ??''}} {{$item->total_transaction}}</td>
                                <td>{{$item->transaction->currency ??''}} {{$item->total_amount}}</td>
                                <td>{{$item->transaction->currency ??''}} {{$item->warehouse_packaging}}</td>
                                <td>{{$item->transaction->currency ??''}} {{$item->fulhive_packaging}}</td>
                                <td>{{$item->transaction->currency ??''}} {{$item->order_warehouse}}</td>
                                <td>{{$item->transaction->currency ??''}} {{$item->order_fulhive}}</td>

                            </tr>
                            @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

    });
</script>


@endsection