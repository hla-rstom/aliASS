@extends('layouts.master')

@section('content')
<div class="container-fluid">
    @include('partials._alert')
    <div class="row justify-content-between">
        <h6 class="h3 mb-3 text-gray-800 ml-3">Warehouse Account</h6>
    </div>
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="tab-content col-md-12">
                    <table id="example" class="table table-borderless mt-4" style="width:100%">
                        <thead class="thead-light">
                            <tr>
                                <th>User</th>
                                <th>Email</th>
                                <th>Warehouse</th>
                                <th>Warehouse Address</th>
                                <th>Capacity</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if (!empty ($approvelist))
                            @foreach ($approvelist as $item)
                            <tr>
                                <td>{{$item->user->name}}</td>
                                <td>{{$item->user->email}}</td>
                                <td>{{$item->name}}</td>
                                <td>{{$item->address}}</td>
                                <td>{{$item->warehousedetail->capacity}}</td>
                                <td>{{$item->created_at}}</td>
                                <td>{{$item->status}} </td>
                                <td>
                                    <div class="row">
                                        <a href="{{ route('detail_warehouse', $item->id) }}" type="button" class="btn btn-primary">Detail</a>
                                        @if ($item->status == 'created')
                                        <form action="{{ route('new_warehouse_approve') }}" method="POST" enctype="multipart/form-data">
                                            @csrf
                                            <input type="hidden" name="warehouse_id" value="{{$item->id}}">
                                            <button type="submit" class="btn btn-success">Approve</button>
                                        </form>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

    });
</script>


@endsection
