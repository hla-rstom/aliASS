@extends('layouts.master')

@section('content')
<div class="container-fluid">
    @include('partials._alert')
    <div class="row justify-content-between">
        <h6 class="h3 mb-3 text-gray-800 ml-3">Warehouse Account</h6>
    </div>
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="tab-content col-md-12">
                    <table id="example" class="table table-borderless mt-4" style="width:100%">
                        <thead class="thead-light">
                            <tr>
                                <th>User</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Region</th>
                                <th>Capacity</th>
                                <th>Property Type</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if (!empty ($approvelist))
                            @foreach ($approvelist as $item)
                            <tr>
                                <td>{{$item->name}}</td>
                                <td>{{$item->email}}</td>
                                <td>{{$item->phone}}</td>
                                <td>{{$item->region}}</td>
                                <td>{{$item->capacity}}</td>
                                <td>
                                    @if ($item->property_type == 'own_property')
                                    Own Property
                                    @elseif ($item->property_type == 'leased_property')
                                    Leased Property
                                    @endif
                                </td>
                                <td>{{$item->created_at}}</td>
                                <td>{{$item->user_status}}</td>
                                <td>
                                    @if ($item->user_status == 'created')
                                    <form action="{{ route('warehouseaccount_approve') }}" method="POST" enctype="multipart/form-data" class="ml-3">
                                        @csrf
                                        <input type="hidden" name="user_id" value="{{$item->id}}">
                                        <button type="submit" class="btn btn-primary">Approve</button>
                                    </form>
                                    @endif
                                </td>
                            </tr>
                            @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

    });
</script>


@endsection
