@extends('layouts.master')

@section('content')
<div class="container-fluid">
    @include('partials._alert')
    <div class="row justify-content-between">
        <h6 class="h3 mb-3 text-gray-800 ml-3">Top Up Approval</h6>
    </div>
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="tab-content col-md-12">
                    <table id="example" class="table table-borderless mt-4" style="width:100%">
                        <thead class="thead-light">
                            <tr>
                                <th>User</th>
                                <th>Date</th>
                                <th>Balance</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if (!empty ($approvelist))
                            @foreach ($approvelist as $item)
                            <tr>
                                <td>{{$item->user->name}}</td>
                                <td>{{$item->date}}</td>
                                <td>RM {{$item->balance}}</td>
                                <td>{{$item->status}}</td>
                                <td>
                                    @if ($item->status !== 'Approved' && $item->type === 'Top Up')
                                    <form action="{{ route('topup_approve') }}" method="POST" enctype="multipart/form-data" class="ml-3">
                                        @csrf
                                        <input type="hidden" name="wallet_id" value="{{$item->id}}">
                                        <input type="hidden" name="user_id" value="{{$item->user_id}}">
                                        <input type="hidden" name="balance" value="{{$item->balance}}">
                                        <button type="submit" class="btn btn-success">Approve Top Up</button>
                                    </form>
                                    @endif
                                    @if ($item->status !== 'Approved'&& $item->type === 'Withdraw')
                                    <form action="{{ route('withdraw_approve') }}" method="POST" enctype="multipart/form-data" class="ml-3">
                                        @csrf
                                        <input type="hidden" name="wallet_id" value="{{$item->id}}">
                                        <input type="hidden" name="user_id" value="{{$item->user_id}}">
                                        <input type="hidden" name="balance" value="{{$item->balance}}">
                                        <button type="submit" class="btn btn-danger">Approve Withdraw</button>
                                    </form>
                                    @endif
                                </td>
                            </tr>
                            @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

    });
</script>


@endsection
