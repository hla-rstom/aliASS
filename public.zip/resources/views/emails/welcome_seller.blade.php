<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Welcome to Fulhive</title>
</head>

<body style="font-family: Arial, sans-serif; color: #333;">
    <div style="background-color: #5356FF; color: white; padding: 20px; text-align: center;">
        <h1>Welcome to the Fulhive Seller Partner Community</h1>
    </div>
    <div style="margin: 20px;">
        <p>{{ $user->name }},</p>
        <p>You have registered yourself as a seller owner.</p>
        <p>PS. If you have any questions, please contact our WA directly at: xxxx</p>

        <p>Best Regards,</p>
        <p>Fulhive</p>
    </div>
</body>

</html>
