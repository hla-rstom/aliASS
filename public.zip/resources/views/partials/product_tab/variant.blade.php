 <div class="tab-pane fade" id="product-variant" role="tabpanel" aria-labelledby="product-variant-tab">
     <div class="card-body">
         <table id="product-table" class="table table-borderless table-striped" style="width:100%">
             
             <thead>
                 <tr>
                     <th><input type="checkbox" id="checkAll" class="large-checkbox" style="transform: scale(1.5);"></th>
                     <th>Variation</th>
                     <th>Sku</th>
                     <th>Stock</th>
                     <!--<th>Cost of Goods</th>-->
                     <th>Status</th>
                     <th>Action</th>
                 </tr>
             </thead>
             <tbody id="searchResults">

                

             </tbody>
         </table>
         
     </div>
 </div>