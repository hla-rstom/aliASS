<!-- Sidebar Wallet -->
<div class="sidebar-card d-none d-lg-flex bg-white mt-4">
    <div style="text-align: justify;">
        <p class="m-0" style="color: #FF5722; font-size: 14px;"><i class="fas fa-solid fa-wallet"></i>  Hive Wallet : RM {{$balance}}</p> <span></span>
        <!-- <p class="m-0 text-primary mt-1" style="margin-left: 20px;"><i class="fas fa-solid fa-coins"></i>  </i>Hive Point :
            RM1000</p> -->
    </div>

</div>