@extends('layouts.master')

@section('content')
<div class="container-fluid">
    <div class="row justify-content-between">
        <h6 class="h3 mb-3 text-gray-800 ml-3">Report Transaction</h6>
        <div class="col-lg-6 text-right mt-4 mb-4">
            <form action="{{ route('transactionexport') }}" method="POST">
                @csrf
                <button type="submit" class="btn btn-outline-primary mr-2">
                    <i class="fas fa-solid fa-download"></i> Download Report
                </button>
            </form>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="col-lg-12 mb-4">
                    @include('partials._filter_report_transaction')
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <table class="table">
                            <thead class="thead-light">
                                <tr>
                                    <th>#</th>
                                    <th scope="col">Invoice</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Marketplace</th>
                                    <th scope="col">Store</th>
                                    <th scope="col">SKU Total</th>
                                    <th scope="col">Qty Total</th>
                                    <th scope="col">Awb</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($transactions as $transaction)
                                <tr>
                                    <th scope="row">{{$loop->iteration}}</th>
                                    <td>{{$transaction->invoice_code}}</td>
                                    <td>{{$transaction->date}}</td>
                                    <td></td>
                                    <td></td>
                                    <td>{{ $transaction->producttransaction->sum('qty') }}</td>
                                    <td>{{ $transaction->producttransaction->pluck('product_id')->unique()->count() }}</td>
                                    <td>{{ $transaction->awbtransaction->no_resi ?? ''}}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
