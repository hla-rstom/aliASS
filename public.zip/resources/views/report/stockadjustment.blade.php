@extends('layouts.master')

@section('content')
<div class="container-fluid">
    <div class="row justify-content-between">
        <h6 class="h3 mb-3 text-gray-800 ml-3">Stock Adjusment</h6>
        <div class="col-lg-6 text-right mt-4 mb-4">
            <button type="button" class="btn btn-outline-primary mr-2">
                <i class="fas fa-solid fa-download"></i> Download Report
            </button>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="col-lg-12 mb-4">
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label for="">Peroid</label><br>
                            <input type="text" class="form-control" id="dateRange" placeholder="Search by Date">

                        </div>
                        <div class="form-group col-md-3">
                            <label for="" class="mb-4" style="margin: 9;"></label><br>
                            <div class="dropdown">
                                <button class="btn btn-outline-secondary dropdown-toggle btn-block" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Marketplaces
                                </button>
                                <div class="dropdown-menu w-100" aria-labelledby="dropdownMenuButton">
                                    <label class="dropdown-item text-truncate ml-2">
                                        <input type="checkbox" id="checkAllmarketplace" /> Check All
                                    </label>
                                    <div id="marketplaceCheckboxes">
                                        @foreach ($types as $type)
                                        <label class="dropdown-item text-truncate ml-2">
                                            <input type="checkbox" class="marketplace" name="types[]" value="{{ $type['value'] }}" {{ $type['is_checked'] ? 'checked' : '' }} /> {{ $type['name'] }}
                                        </label>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-2">
                            <label for="" class="mb-4" style="margin: 9;"></label><br>
                            <div class="dropdown">
                                <button class="btn btn-outline-secondary dropdown-toggle btn-block" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Warehouse
                                </button>
                                <div class="dropdown-menu w-100" aria-labelledby="dropdownMenuButton">
                                    <label class="dropdown-item text-truncate ml-2">
                                        <input type="checkbox" id="checkAllwarehouse" /> Check All
                                    </label>
                                    <div id="warehouseCheckboxes">
                                        @foreach ($warehouses as $warehouse)
                                        <label class="dropdown-item text-truncate ml-2">
                                            <input type="checkbox" class="warehouse" name="warehouses[]" value="{{ $warehouse['id'] }}" {{ $warehouse['is_checked'] ? 'checked' : '' }} /> {{ $warehouse['name'] }}
                                        </label>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-2">
                            <label for="" class="mb-4" style="margin: 9;"></label><br>
                            <div class="input-group justify-content-end">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                </div>
                                <input type="text" class="form-control" placeholder="Find..." aria-label="Cari" aria-describedby="basic-addon1">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <table class="table">
                            <thead class="thead-light">
                                <tr>
                                    <th>#</th>
                                    <th scope="col">Log ID</th>
                                    <th scope="col">Date created</th>
                                    <th scope="col">Type</th>
                                    <th scope="col">Note</th>
                                    <th scope="col">User</th>
                                    <th scope="col">Warehouse</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th scope="row"></th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <!-- Add other table rows here -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $('#dateRange').daterangepicker({
        locale: {
            format: 'YYYY-MM-DD'
        }
    });

    $('#checkAllmarketplace').click(function() {
        $('#marketplaceCheckboxes .marketplace').prop('checked', this.checked);
    });

    $('#marketplaceCheckboxes .marketplace').click(function() {
        if (false === $(this).prop("checked")) {
            $('#checkAllmarketplace').prop('checked', false);
        }
        if ($('#marketplaceCheckboxes .marketplace:checked').length === $('#marketplaceCheckboxes .marketplace').length) {
            $('#checkAllmarketplace').prop('checked', true);
        }
    });

    $('#checkAllwarehouse').click(function() {
        $('#warehouseCheckboxes .warehouse').prop('checked', this.checked);
    });

    $('#warehouseCheckboxes .warehouse').click(function() {
        if (false === $(this).prop("checked")) {
            $('#checkAllwarehouse').prop('checked', false);
        }
        if ($('#warehouseCheckboxes .warehouse:checked').length === $('#warehouseCheckboxes .warehouse').length) {
            $('#checkAllwarehouse').prop('checked', true);
        }
    });
</script>

@endsection
