@extends('layouts.master')

@section('content')
<div class="container-fluid">
    <div class="row justify-content-between">
        <h6 class="h3 mb-3 text-gray-800 ml-3">Product Sales</h6>
        <div class="col-lg-6 text-right mt-4 mb-4">
            <button type="button" class="btn btn-outline-primary mr-2">
                <i class="fas fa-solid fa-download"></i> Download Report
            </button>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="col-lg-12 ml-4 mb-4">
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label for="">Date</label><br>
                            <input type="text" class="form-control" id="dateRange" placeholder="Search by Date">

                        </div>
                        <div class="form-group col-md-2">
                            <label for="">Filter</label>
                            <select class="form-control" id="select2-sort">
                                <option value="all">All</option>
                                <!-- Add other status options here -->
                            </select>
                        </div>
                        <div class="form-group col-md-2">
                            <label for="" class="mb-4" style="margin: 9;"></label><br>
                            <div class="input-group justify-content-end">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                </div>
                                <input type="text" class="form-control" placeholder="Find..." aria-label="Cari" aria-describedby="basic-addon1">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row ml-4">
                    <div class="col-lg-11">
                        <table class="table">
                            <thead class="thead-light">
                                <tr>
                                    <th>#</th>
                                    <th scope="col">Product Name</th>
                                    <th scope="col">SKU</th>
                                    <th scope="col">Sales Total</th>
                                    <th scope="col">Sales Value</th>
                                    <th scope="col">Capital</th>
                                    <th scope="col">Profit</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th scope="row">1</th>
                                    <td>Mark</td>
                                    <td>Otto</td>
                                    <td>Otto</td>
                                    <td>Otto</td>
                                    <td>Otto</td>
                                </tr>
                                <!-- Add other table rows here -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $('#dateRange').daterangepicker({
        locale: {
            format: 'YYYY-MM-DD'
        }
    });
</script>

@endsection
