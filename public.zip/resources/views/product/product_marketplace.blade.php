@extends('layouts.master')

@section('content')
<style>
    .list-group-item-action {
        display: flex;
        flex-direction: column;
        /* Stack items vertically */
        align-items: center;
        /* Center-align items horizontally */
        text-align: center;
        /* Ensure text labels are centered below images */
        gap: 5px;
        /* Adjust the space between the image and the text */
        max-width: 120px;
        border: none
    }

    .list-group.d-flex {
        flex-wrap: nowrap;
        /* Prevents wrapping of items to ensure inline display */
        overflow-x: auto;
        /* Adds horizontal scroll on small screens */
    }
</style>
<div class="container-fluid">
    @include('partials._alert')

    <div class="row justify-content-between">
        <h6 class="h3 mb-3 text-gray-800 ml-3">Products Marketplace</h6>
        <div class="text-right mr-4">
            <button class="btn btn-primary" data-toggle="modal" data-target="#addStoreModal">Add Store</button>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="col-md-12 ml-4">
                    @if($stores->isNotEmpty())
                    <table id="example" class="table table-borderless table-striped" style="width:100%">
                        <thead>
                            <tr>
                                <th>Store Name</th>
                                <th>Marketplace</th>
                                <th>Warehouse</th>
                                <th>Mapping Product</th>
                                <!--<th>Auto Sync Stock</th>-->
                                <th>Auto Sync Transaction</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($stores as $store )
                            <tr>
                                <td><a href="{{route('marketplacedetail',$store->shop_id)}}">{{$store->shop_name}}</a></td>
                                <td>{{$store->driver}}</td>
                                <td></td>
                                <td></td>
                               <!-- <td>
                                    <div class="col-md-4">
                                        <div class="custom-control custom-switch">
                                            <input type="hidden" name="sync_stock" value="{{$store->sync_stock ? 'yes' : 'no'}}">
                                            <input type="checkbox" class="custom-control-input" id="syncStockSwitch{{$store->id}}" data-shop-id="{{$store->shop_id}}" data-type="stock" {{ $store->sync_stock ? 'checked' : '' }}>
                                            <label class="custom-control-label" for="syncStockSwitch{{$store->id}}"></label>
                                        </div>
                                    </div>
                                </td> -->
                                <td>
                                   <div class="col-md-4">
                                       <div class="custom-control custom-switch">
                                           <input type="hidden" name="sync_txn" value="{{$store->sync_txn ? 'yes' : 'no'}}">
                                           <input type="checkbox" class="custom-control-input" id="syncTxnSwitch{{$store->id}}" data-shop-id="{{$store->shop_id}}" data-type="transaction" {{ $store->sync_txn ? 'checked' : '' }}>
                                           <label class="custom-control-label" for="syncTxnSwitch{{$store->id}}"></label>
                                       </div>
                                   </div>
                                </td>
                                <td>
                                    <form action="{{ route('deletemarketplace', $store->id) }}" method="POST">
                                        @csrf
                                        <button class="btn btn-outline-danger" href="#" type="submit" onclick="return confirm('Are you sure you want to delete this record?')"><i class="fas fa-regular fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    @else
                    <div class="card mb-3">
                        <div class="card-body text-center">
                            <img class="img-fluid px-3 px-sm-4 mt-3 mb-4" style="width: 25rem;" src="{{ asset('storage/images/1705557639_nodata.jpg') }}" alt="...">
                            <h5 class="card-title">There is no Marketplace yet</h5>
                            <p class="card-text">Let's add your Marketplace.</p>
                            <a class="btn btn-primary btn-icon-split" data-toggle="modal" data-target="#addStoreModal">
                                <span class="icon text-white-50">
                                    <i class="fas fa-plus"></i>
                                </span>
                                <span class="text">Add Store</span>
                            </a>
                        </div>
                    </div>
                    @endif
                </div>
            </div>
            <!-- end card tim saya -->
        </div>
    </div>
</div>

<!-- Add Store Modal -->
<div class="modal fade" id="addStoreModal" tabindex="-1" role="dialog" aria-labelledby="addStoreModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addStoreModalLabel">Add Store</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="list-group d-flex flex-row justify-content-around align-items-center">
                    <a href="{{route('authorize', 'shopee')}}" class="list-group-item list-group-item-action d-flex flex-column align-items-center">
                        <img src="{{asset('asset/img/shopee.png')}}" alt="Shopee" width="50">
                        <span>Shopee</span>
                    </a>
                    <a href="{{route('authorize', 'tiktok')}}" class="list-group-item list-group-item-action d-flex flex-column align-items-center">
                        <img src="{{asset('asset/img/tiktok.png')}}" alt="TikTok" width="50">
                        <span>TikTok</span>
                    </a>
                    <a href="{{route('authorize', 'lazada')}}" class="list-group-item list-group-item-action d-flex flex-column align-items-center">
                        <img src="{{asset('asset/img/lazada.png')}}" alt="Lazada" width="50">
                        <span>Lazada</span>
                    </a>
                    <!--<a href="{{route('authorize', 'woocommerce')}}" class="list-group-item list-group-item-action d-flex flex-column align-items-center">-->
                    <!--    <img src="{{asset('asset/img/woocommerce.png')}}" alt="WooCommerce" width="50">-->
                    <!--    <span>WooCommerce</span>-->
                    <!--</a>-->
                </div>
            </div>


        </div>
    </div>
</div>
<script> 
$(document).ready(function() {
    $('.custom-control-input').change(function() {
        var shopId = $(this).data('shop-id');
        var type = $(this).data('type');
        var value = $(this).is(':checked') ? 'yes' : 'no';
        
        $.ajax({
            url: "{{ route('syncSwitch') }}",
            type: "POST",
            data: {
                _token: '{{ csrf_token() }}',
                shop_id: shopId,
                type: type,
                value: value
            },
            success: function(response) {
                alert('Sync settings updated successfully');
            },
            error: function(xhr, status, error) {
                alert('Error updating sync settings');
            }
        });
    });
});
</script>
@endsection