@extends('layouts.master')

@section('content')
<div class="container-fluid">
    @include('partials._alert')
    <div class="row justify-content-between">
        <h6 class="h3 mb-3 text-gray-800 ml-3">Price Setting</h6>
        <div class="text-right">
            <button class="btn btn-secondary" data-toggle="modal" data-target="#uploadModal">Import of price changes</button>
            <a href="{{ route('exportpriceList') }}" class="btn btn-primary">Download List price changes</a>
        </div>
    </div>

    <!-- Modal Upload Product -->
    <div class="modal fade" id="uploadModal" tabindex="-1" aria-labelledby="uploadModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <!-- <h5 class="modal-title" id="uploadModalLabel">Product Information</h5> -->
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <div class="row mt-4 mb-4">
                        <h4 class="text-primary mb-2 mx-auto">Upload Product</h4>
                    </div>
                    <!-- Tab links -->
                    <ul class="nav nav-tabs">
                        <li class="nav-item">
                            <a class="nav-link active" id="download-tab" data-toggle="tab" href="#download">Download Template</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="upload-tab" data-toggle="tab" href="#upload">Upload File Template</a>
                        </li>
                    </ul>

                    <!-- Tab content -->
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="download">
                            <!-- Content for Download Template tab -->
                            <form action="{{ route('templatechangesprice') }}" method="POST" enctype="multipart/form-data" class="ml-3">
                                @csrf

                                <div class="form-group mt-4">
                                    <button type="submit" class="btn btn-primary">Download Template</button>
                                </div>
                                <p>Please download the excel file template here to add Price Change Batches. Easy way to Import Price Change Batches.</p>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                    <!-- <button type="button" class="btn btn-primary" id="next">Selanjutnya</button> -->
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="upload">
                            <!-- Content for Upload File Template tab -->
                            <form action="{{ route('importchangesprice') }}" method="POST" enctype="multipart/form-data" class="ml-3">
                                @csrf

                                <div class="input-group mb-3 mt-4">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="inputFile" name="file" aria-describedby="inputFileAddon">
                                        <label class="custom-file-label" for="inputFile">Choose file</label>
                                    </div>
                                </div>
                                <p>Please select your Excel file (.xlsx) here. The system can only process the first 500 rows.</p>
                                <!-- Add any other form fields needed for uploading -->
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                    <button type="submit" class="btn btn-primary">Upload</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End modal -->
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-body">
                @include('partials._filter_setting_price')
                <div class="row ml-4">
                    <div class="col-lg-12">
                        <table id="example" class="table table-borderless" style="width:100%">
                            @if($products->isNotEmpty())
                            <thead class="thead-light">
                                <tr>
                                    <th rowspan="2">Product</th>
                                    <th></th>
                                    <th>Price</th>
                                    <th>History</th>
                                </tr>
                            </thead>
                            <tbody id="searchResults">
                                @foreach ($products as $product )
                                @php

                                 $images = json_decode($product->image, true);

                                // Fetch from PhotoProduct if $images is empty or not an array
                                    if (empty($images) || !is_array($images) || empty($images[0])) {
                                        $photo = $product->photos()->first(); 
                                        $photoUrl = $photo ? asset('storage/' . $photo->path) : null;
                                    } else {
                                        $photoUrl = asset($images[0]);
                                    }
                                @endphp
                                <tr>
                                    <td rowspan="2"class="hover-image">                             
                             <img src="{{ $photoUrl }}" alt="Main Photo" style="width: 50px; height: auto;"> 
                             <img src="{{ $photoUrl }}" alt="Popup Photo" class="popup-image"> 
                                    </td>
                                    <td>{{ $product->name }} <br>
                                        SKU : {{ $product->sku}}
                                    </td>
                                    <td>{{ $product->currency }} {{ $product->consumer_price }} </td>
                                    <td>
                                        <div class="row">
                                            Last Updated <br> {{ $product->updated_at }}
                                        </div>
                                    </td>

                                </tr>
                                <tr>
                                    <td></td>
                                </tr>


                                @endforeach
                                @else

                                <div class="card mb-3 text-center">
                                    <div class="card-body">
                                        <img class="img-fluid px-3 px-sm-4 mt-3 mb-4" style="width: 10rem;" src="{{ asset('storage/images/1705557639_nodata.jpg') }}" alt="...">
                                        <h5>There is no Product yet</h5>
                                        <p>Let's create your Product.</p>
                                    </div>
                                </div>
                                @endif
                            </tbody>
                        </table>
                        <div class="d-flex justify-content-end mt-4">

                            {!! $products->links() !!}
                        </div>
                    </div>
                </div>
            </div>
            <!-- end card tim saya -->
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        document.querySelectorAll('#priceUpdateForm input').forEach(input => {
            input.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault(); // Prevent the default form action
                    document.getElementById('priceUpdateForm').submit(); // Submit the form
                }
            });
        });

    });
</script>

@endsection