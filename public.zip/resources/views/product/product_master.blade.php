<style>
    :root {
        --gray: #eeeeee;
        /*#ebeded;*/
    }

    .nested-select-container {
        position: relative;
        z-index: 999999999999999999;
        top: 0;
        display: flex;
    }

    .nested-select-item {
        padding: 0.2rem 0.4rem;
        text-transform: capitalize;
        width: 100%;
        max-height: 12rem;
        overflow-y: scroll;
        overflow-x: hidden;
    }

    .nested-select-value {
        font-size: 1rem;
        padding: 0.4rem 0.6rem;
        border-left: 0.5px solid var(--gray);
        border-right: 1px solid var(--gray);
        display: flex;
        justify-content: space-between;
    }


    @keyframes spin {
        0% {
            transform: rotate(0deg);
        }

        100% {
            transform: rotate(360deg);
        }
    }

    .hover-image {
    position: relative; /* Set relative positioning to contain the popup */
}


</style>
@extends('layouts.master')

@section('content')
<div class="container-fluid">
    @include('partials._alert')

    <div class="row col-lg-12">
        <div class="col-md-6 text-left">
            <h6 class="h3 mb-3 text-gray-800">Product Master</h6>
        </div>
        <div class="col-md-6">
            <div class="row justify-content-end">
                <div class="dropdown mr-2">
                    <button class="btn btn-outline-warning dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                        Product
                    </button>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#addModal"><i class="fas fa-solid fa-plus"></i> Add Product</a>
                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#pullOrder"><i class="fas fa-solid fa-arrow-down"></i> Pull Product</a>
                        <a class="dropdown-item" href="{{ route('exportProductList') }}"><i class="fas fa-regular fa-download"></i> Download Product</a>
                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#uploadModal"><i class="fas fa-solid fa-arrow-up"></i> Upload Product</a>
                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#uploadEditModal"><i class="fas fa-solid fa-pen"></i> Edit Product</a>
                    </div>
                </div>
                <div class="dropdown">
                    <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                        Product Bundling
                    </button>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#addbundlingModal"><i class="fas fa-solid fa-plus"></i> Add Bundling</a>
                        <!--<a class="dropdown-item" href="#"><i class="fas fa-regular fa-download"></i> Download Bundling</a>-->
                        <!--<a class="dropdown-item" href="#"><i class="fas fa-solid fa-arrow-up"></i> Upload Bundling</a>-->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Pull order Modal -->
    <div class="modal fade" id="pullOrder" tabindex="-1" role="dialog" aria-labelledby="pullOrderLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="pullOrderLabel"> Pull Product Marketplace</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    @if($stores->isEmpty())
                    <div class="alert-warning" role="alert">
                        You don't have a registered store yet! Please add your store below.
                    </div>
                    <div class="text-center mt-3">
                        <a href="{{ route('marketplace') }}" class="btn btn-warning">Add Store</a>
                    </div>
                    @else
                    @foreach ($stores as $item)
                    <div class="card mb-2">
                        <div class="card-body">
                            <div class="row align-items-center justify-content-around">
                                <div class="col-auto">
                                    <a href="{{ route('pullproduct', ['type' => $item->driver, 'shopid' => $item->shop_id]) }}" class="list-group-item list-group-item-action d-flex align-items-center">
                                        <img src="{{ asset('asset/img/' . $item->driver . '.png') }}" alt="{{ $item->driver }}" width="50">
                                        <span class="ml-2">{{ $item->shop_name }}</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                    @endif
                </div>
            </div>
        </div>
    </div>


    <!-- Modal Add Product -->
    <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addModalLabel">Product Information</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('storeproduct') }}" method="POST" enctype="multipart/form-data" class="ml-3">
                        @csrf
                        <div class="form-row">
                            <div class="form-group col-lg-8 mr-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="text" class="form-control" name="name" value="{{ old('name') }}">
                            </div>
                            <div class="form-group">
                                <label for="sku" class="col-form-label">Sku Number</label>
                                <input type="text" class="form-control" name="sku" value="{{ old('sku') }}">
                            </div>
                        </div>
                        <div class="form-group" style="position: relative;">
                            <label for="nested-select" class="col-form-label">Category</label>
                            <input id="nested-select" type="button" value="-- Choose Category --" onclick="eventClick(this)" class="form-control form-select" />
                            <input type="hidden" name="category_id" id="category_id" value="-" />
                            <input type="hidden" name="category" id="category" value="-" />
                        </div>
                        <div class="form-group">
                            <label for="message-text" class="col-form-label">Description</label>
                            <textarea class="form-control" id="message-text" cols="40" name="description">{{ old('description') }}</textarea>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-12">
                                <label for="weight" class="col-form-label">Weight</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" name="weight" value="{{ old('weight') }}" aria-describedby="basic-addon2">
                                    <div class="input-group-append">
                                        <span class="input-group-text" id="basic-addon2">Gram</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="size" class="col-form-label">Size</label>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="input-group">

                                        <input type="text" class="form-control" name="size" placeholder="Length" value="{{ old('size') }}" aria-describedby="basic-addon1">
                                        <div class="input-group-append">
                                            <span class="input-group-text" id="basic-addon1">Cm</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="input-group">

                                        <input type="text" class="form-control" name="width" placeholder="Width" value="{{ old('width') }}" aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <span class="input-group-text" id="basic-addon2">Cm</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="input-group">
                                        <input type="text" class="form-control" name="height" placeholder="Height" value="{{ old('height') }}" aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <span class="input-group-text" id="basic-addon2">Cm</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="custom-control custom-switch">
                                        <input type="hidden" name="fefo" value="no">
                                        <input type="checkbox" class="custom-control-input" id="fefoSwitch" name="fefo" value="yes" {{ old('fefo') == 'yes' ? 'checked' : '' }}>
                                        <label class="custom-control-label" for="fefoSwitch">FEFO</label>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="custom-control custom-switch">
                                        <input type="hidden" name="qc" value="no">
                                        <input type="checkbox" class="custom-control-input" id="defaultQCSwitch" name="qc" value="yes" {{ old('qc') == 'yes' ? 'checked' : '' }}>
                                        <label class="custom-control-label" for="defaultQCSwitch">Default QC</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
                @include('partials._photo_upload_form')

                <div class="ml-4">
                    <!-- Toggle Switch for Variations -->
                    <div class="custom-control custom-switch mb-3">
                        <input type="checkbox" class="custom-control-input" id="variasiSwitch">
                        <label class="custom-control-label" for="variasiSwitch">Variation Product</label>
                    </div>
                    <div id="variations-container">
                        <!-- Variations will be dynamically added here -->
                    </div>

                    <button type="button" class="btn btn-outline-secondary btn-block" id="add-variation" style="display: none;">+ Variasi</button>

                    <div class="form-row">
                        <div class="form-group col-lg-6">
                            <label for="cost_of_goods" class="col-form-label">Cost of goods</label>
                            <input type="text" class="form-control" name="cost_of_goods" value="{{ old('cost_of_goods') }}">
                        </div>
                        <div class="form-group col-lg-5">
                            <label for="consumer_price" class="col-form-label">Consumer price</label>
                            <input type="text" class="form-control" name="consumer_price" value="{{ old('consumer_price') }}">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-lg-6">
                            <label for="stock" class="col-form-label">Stock</label>
                            <input type="text" class="form-control" name="stock" value="{{ old('stock') }}">
                        </div>
                        <div class="form-group col-lg-5">
                            <label for="category">Store</label>
                            <select name="shop_id" id="category" class="form-control mb-2">
                                <option value="">-- Select Store --</option>
                                @foreach ($stores as $store)
                                    <option value="{{ $store->shop_id }}">{{ $store->shop_name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-warning">Submit</button>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- End modal -->

    <!-- Modal add bundling-->
    <div class="modal fade" id="addbundlingModal" tabindex="-1" aria-labelledby="addbundlingModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addbundlingModalLabel">Add Product Bundling</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('storebundling') }}" method="POST" enctype="multipart/form-data" class="ml-3">
                        @csrf
                        <div class="form-row">
                            <div class="form-group col-lg-8 mr-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="text" class="form-control" name="name" value="{{ old('name') }}">
                            </div>
                            <div class="form-group">
                                <label for="code" class="col-form-label">Bundling Code</label>
                                <input type="text" class="form-control" name="code" value="{{ old('code') }}">
                            </div>
                        </div>
                        <div class="card shadow col-lg-12 mb-3">
                            <div class="card-body">
                                <p class="mb-2"><b>Add Product Bundling</b></p>
                                <div class="row mt-4">

                                    <div class="col-auto ml-auto"> <!-- This column auto-sizes and is pushed to the right -->
                                        <!-- Search Input -->
                                        <div class="input-group">
                                            <input type="text" id="searchInputbundling" class="form-control" placeholder="Search here">
                                        </div>
                                    </div>
                                </div>
                                <table id="productbundling-table" class="table table-borderless table-striped mt-2" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Sku</th>
                                            <th>Cost of Goods</th>
                                            <th>Consumer Price</th>
                                            <th>Qty</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="searchResultsbundling">

                                    </tbody>
                                </table>
                                <button type="button" class="btn btn-outline-warning btn-block">+ Add Product</button>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-8 mr-3">
                                <label for="bundling_price" class="col-form-label">Bundling Price</label>
                                <input type="text" class="form-control" name="bundling_price" value="{{ old('bundling_price') }}">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-warning">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Upload Product -->
    <div class="modal fade" id="uploadModal" tabindex="-1" aria-labelledby="uploadModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <div class="row mt-4 mb-4">
                        <h4 class="text-primary mb-2 mx-auto">Upload Product</h4>
                    </div>
                    <ul class="nav nav-tabs">
                        <li class="nav-item">
                            <a class="nav-link active" id="download-tab" data-toggle="tab" href="#download">Download Template</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="upload-tab" data-toggle="tab" href="#upload">Upload File Template</a>
                        </li>
                    </ul>

                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="download">
                            <form action="{{ route('downloadtemplate') }}" method="POST" enctype="multipart/form-data" class="ml-3">
                                @csrf
                                <div class="form-group mt-4">
                                    <label for="template">Template Product</label>
                                    <select class="form-control" id="template" name="template">
                                        <option value="">-- Choose Template --</option>
                                        <option value="master-product">Master Product</option>
                                        <!-- <option value="master-category">Master Category</option>
                                        <option value="category-product">Category Product</option> -->
                                    </select>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-warning">Download Template</button>
                                </div>
                                <p>Please download the excel file template here to add the Product Upload List. The easy way to Upload Products.</p>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <!-- <button type="button" class="btn btn-warning" id="next">Selanjutnya</button> -->
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="upload">
                            <!-- Content for Upload File Template tab -->
                            <form action="{{ route('importtemplate') }}" method="POST" enctype="multipart/form-data" class="ml-3">
                                @csrf
                                <div class="form-group mt-4">
                                    <label for="template">Template Product</label>
                                    <select class="form-control" id="template" name="template">
                                        <option value="">-- Choose Template --</option>
                                        <option value="master-product">Master Product</option>
                                        <!-- <option value="master-category">Master Category</option>
                                        <option value="category-product">Category Product</option> -->
                                    </select>
                                </div>
                                <div class="input-group mb-3">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="inputFile" name="file" aria-describedby="inputFileAddon">
                                        <label class="custom-file-label" for="inputFile">Choose file</label>
                                    </div>
                                </div>
                                <p>Please select your excel file(.xlxs) here. The system can only process the first 500 rows</p>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-warning">Upload</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End modal -->

    <!-- Modal Edit import Product -->
    <div class="modal fade" id="uploadEditModal" tabindex="-1" aria-labelledby="uploadEditModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <div class="row mt-4 mb-4">
                        <h4 class="text-primary mb-2 mx-auto">Upload Product</h4>
                    </div>

                    <ul class="nav nav-tabs nav-tabs-edit" id="uploadTab-edit" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link nav-link-edit active" id="download-tab-edit" data-toggle="tab" href="#download-pane-edit" role="tab" aria-controls="download" aria-selected="true">Download Template</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-link-edit" id="upload-tab-edit" data-toggle="tab" href="#upload-pane-edit" role="tab" aria-controls="upload" aria-selected="false">Upload File Template</a>
                        </li>
                    </ul>


                    <div class="tab-content tab-content-edit" id="uploadTabContent-edit">
                        <div class="tab-pane tab-pane-edit fade show active" id="download-pane-edit" role="tabpanel" aria-labelledby="download-tab-edit">

                            <form action="{{ route('updateMasterSkuExport') }}" method="POST" enctype="multipart/form-data" class="ml-3">
                                @csrf
                                <div class="form-group mt-4">
                                    <button type="submit" class="btn btn-warning">Download Template</button>
                                </div>
                                <p>Please download the excel file template here to add Price Change Batches. Easy way to Import Price Change Batches.</p>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane tab-pane-edit fade" id="upload-pane-edit" role="tabpanel" aria-labelledby="upload-tab-edit">
                            <form action="{{ route('updateMasterSkuImport') }}" method="POST" enctype="multipart/form-data" class="ml-3">
                                @csrf
                                <div class="input-group mb-3 mt-4">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input-edit" id="inputFile-edit" name="file" aria-describedby="inputFileAddon">
                                        <label class="custom-file-label" for="inputFile-edit">Choose file</label>
                                    </div>
                                </div>
                                <p>Please select your Excel file (.xlsx) here. The system can only process the first 500 rows.</p>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-warning">Upload</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End modal -->


    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-header py-3 mb-4">
                <div class="row">
                    <ul class="nav nav-tabs justify-content-between" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="all-products-tab" data-toggle="tab" href="#all-products" role="tab" aria-controls="home" aria-selected="true">All Product</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="products-unit-tab" data-toggle="tab" href="#products-unit" role="tab" aria-controls="profile" aria-selected="false">Products Unit</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="product-variant-tab" data-toggle="tab" href="#product-variant" role="tab" aria-controls="contact" aria-selected="false">Product Varian</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="products-bundling-tab" data-toggle="tab" href="#products-bundling" role="tab" aria-controls="contact" aria-selected="false">Products Bundling</a>
                        </li>
                    </ul>
                </div>


                <div class="text-right col-md-4 mt-4">
                    <div class="col-auto ml-auto">
                        <div class="input-group">
                            <input type="text" id="searchInput" class="form-control" placeholder="Search here">
                        </div>
                    </div>
                </div>
                <div class="tab-content col-md-12">
                    @include('partials.product_tab.all')
                    @include('partials.product_tab.unit')
                    @include('partials.product_tab.variant')
                    @include('partials.product_tab.bundling')
                </div>



                <!-- end card tim saya -->
            </div>
        </div>
    </div>


    <script>
        function randstr(len = 8) {
            let chars = "abcdefghijklmnopqrstuvwxyz0123456789".split("");
            let res = "ID";

            for (let i = 0; i < len; i++) {
                res += chars[Math.floor(Math.random() * chars.length)];
            }

            return res;
        }
        class NestedSelect {
            constructor({
                target,
                items,
                currentElement,
                level = 1
            }) {
                this.target = target;
                this.items = items;
                this.id = randstr();
                this.loaded = false;
                this.level = level;
                this.currentElement = currentElement;

            }

            /**
             * #method loadContainer
             * method utama untuk mengenerate tampilan select bercabang
             */
            loadContainer() {
                const {
                    id,
                    target,
                    items,
                    loaded,
                    level,
                    currentElement
                } = this;
                let options = "";
                let currentItems = [];

                /**
                 * #describe
                 * pengecekan untuk select bercabang sudah di buat tampilan nya atau belum
                 */
                if (loaded) return this.unLoadContainer();

                for (let i = 0; i < items.length; i++) {
                    let item = items[i];
                    window[`nested_#${id}_${i}`] = item.items || [];
                    item.items = item.items || [];

                    /**
                     * #describe
                     * pembuatan tampilan element option
                     */
                    options += `
              <div data-category_id="${ item.id }" data-value="${item.value}" class="nested-select-value ${item.items.length > 0 ? "select" : "value"}">
                ${item.label}
                <span class="icon">
                  <svg xmlns="http://www.w3.org/2000/svg" height="16" width="10" viewBox="0 0 320 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z"/></svg>
                <span/>
              </div>
            `;
                    currentItems.push(item);
                }

                /**
                 * #describe
                 * pembuatan tampilan elemet select bercabang
                 */
                if (document.querySelector(".nested-select-container") === null) {
                    target.insertAdjacentHTML(
                        "afterend",
                        `
                <div class="nested-select-container">
                  <div class="nested-select-item" id="${id}">
                      ${options}
                  </div>
                </div>
            `,
                    );
                } else {
                    document.querySelector(".nested-select-container").insertAdjacentHTML(
                        "beforeend",
                        `
              <div class="nested-select-item" id="${id}">
                  ${options}
              </div>
            `,
                    );
                }

                let childrens = document.querySelectorAll(`#${id} .nested-select-value`);
                childrens.forEach((children, i) => {
                    /**
                     * #describe
                     * menginisiasi ulang untuk membuat tampilan select bercabang
                     */
                    let nested = new NestedSelect({
                        target: target,
                        level: level + 1,
                        currentElement: children,
                        items: window[`nested_#${id}_${i}`],
                    });

                    /**
                     * #describe
                     * event listener untuk setiap element option
                     */
                    children.addEventListener("click", function() {
                        let isParentOpened = this.parentElement.querySelector(".active");
                        let isActive = this.getAttribute("class").split(" ").includes("active");
                        let categoryId = this.getAttribute("data-category_id")
                        let isThisHasValue = this.getAttribute("class")
                            .split(" ")
                            .includes("value");

                        /**
                         * #describe
                         * pengecekan apabila option yang di pilih tidak memiliki subitem lagi
                         */
                        if (isThisHasValue) {
                            let parents = this.closest(
                                ".nested-select-container",
                            ).querySelectorAll(".nested-select-value.active");
                            let values = [];

                            parents.forEach((element) => values.push(element.innerText));
                            values.push(this.innerText);

                            /**
                             * #describe
                             * menyimpan hasil value ke dalam input target
                             */
                            $("#category_id").remove();
                            $("#category").remove();
                            target.value = values.toString().replace(/\,/gm, " › ");
                            $(target).after(`
                  <input name="category_id" id="category_id" type="hidden" value="${ categoryId }" />
                  <input name="category" id="category" type="hidden" value="${ target.value }" />
                `)

                            for (let level = 1; level <= 3; level++) {
                                delete window[`nested_object_level${ level }`];
                            }
                            return document.querySelector(".nested-select-container").remove();
                        }

                        /**
                         * #describe
                         * pengecekan apabila select disorot atau tidak
                         */
                        if (isParentOpened) {
                            if (!isActive) {
                                // remove all children if exists
                                let childs = target.querySelectorAll(".nested-select-item");

                                if (childs) {
                                    for (let j = 1; j <= 3; j++) {
                                        let otherNestedState = window[`nested_object_level${ j }`];

                                        if (otherNestedState) {
                                            if (j !== level && j > level) otherNestedState?.unLoadContainer();
                                            if (j >= level) otherNestedState.currentElement?.classList.remove("active");
                                        }
                                    }
                                }

                                nested.loadContainer();
                            } else nested.unLoadContainer();
                        } else {
                            nested.loadContainer();
                        }

                        /**
                         * #describe
                         * perubahan class active untuk option yang telah dipilih
                         */
                        this.classList.toggle("active");
                    });
                });

                window[`nested_object_level${ level }`] = this;
                this.loaded = true;
            }

            /**
             * #method unLoadContainer
             * untuk mereset tampilan select bercabang
             */
            unLoadContainer() {
                const {
                    id,
                    target
                } = this;

                if (!document.querySelector(`#${id}`)) {
                    this.loaded = false;
                    this.loadContainer();
                    target.setAttribute("value", "");
                    return false;
                }

                document.querySelector(`#${id}`).remove();
                $("#category_id").remove();
                $("#category").remove();
                this.loaded = false;
            }

            /**
             * #method init
             * untuk memuat method² utama pada class NestedSelect
             */
            init() {
                this.loadContainer();
            }


        }

        async function eventClick(event) {
            let categorySelect = event;
            let value = event.value;
            let items = [];
            event.value = "loading ..."
            let categories = window.categories || await (await fetch("/categories")).json();
            window.categories = categories
            event.value = value

            let nested = window.nested || new NestedSelect({
                target: categorySelect,
                items: categories,
                currentElement: categorySelect,
            });
            window.nested = nested
            nested.init();
        }

        document.addEventListener('DOMContentLoaded', function() {
            const variasiSwitch = document.getElementById('variasiSwitch');
            const variationsContainer = document.getElementById('variations-container');
            const addVariationButton = document.getElementById('add-variation');

            variasiSwitch.addEventListener('change', function() {
                if (this.checked) {
                    addVariation();
                    addVariationButton.style.display = 'block'; // Show the add variation button
                } else {
                    variationsContainer.innerHTML = ''; // Remove all variations
                    addVariationButton.style.display = 'none'; // Hide the add variation button
                }
            });

            addVariationButton.addEventListener('click', function() {
                addVariation();
            });

            function addVariation() {
                // Create a new card element for the variation
                const card = document.createElement('div');
                card.className = 'card mb-3';
                const cardBody = document.createElement('div');
                cardBody.className = 'card-body';
                card.appendChild(cardBody);

                // Add the variation name input
                const nameFormGroup = document.createElement('div');
                nameFormGroup.className = 'form-group';
                const nameLabel = document.createElement('label');
                nameLabel.textContent = 'Variation Name';
                const nameInput = document.createElement('input');
                nameInput.type = 'text';
                nameInput.className = 'form-control variation-name';
                nameInput.name = 'variations[][name]';
                nameInput.maxLength = '24';
                nameInput.placeholder = 'Name';
                nameFormGroup.appendChild(nameLabel);
                nameFormGroup.appendChild(nameInput);
                cardBody.appendChild(nameFormGroup);

                // Add the options container
                const optionsFormGroup = document.createElement('div');
                optionsFormGroup.className = 'form-group';
                const optionsLabel = document.createElement('label');
                optionsLabel.textContent = 'Variation Options';
                const optionsContainer = document.createElement('div');
                optionsContainer.className = 'options-container';
                optionsFormGroup.appendChild(optionsLabel);
                optionsFormGroup.appendChild(optionsContainer);
                cardBody.appendChild(optionsFormGroup);

                // Add option button
                const addOptionButton = document.createElement('button');
                addOptionButton.className = 'btn btn-warning add-option';
                addOptionButton.textContent = '+ Add Option';
                addOptionButton.addEventListener('click', function() {
                    addOption(optionsContainer);
                });
                optionsFormGroup.appendChild(addOptionButton);

                // Append the new variation card to the container
                variationsContainer.appendChild(card);
            }

            function addOption(optionsContainer) {
                const totalOptions = optionsContainer.querySelectorAll('.option-group').length;
                if (totalOptions < 20) {
                    const optionGroup = document.createElement('div');
                    optionGroup.classList.add('option-group', 'input-group', 'mb-3');

                    const optionInput = document.createElement('input');
                    optionInput.type = 'text';
                    optionInput.name = 'options[]';
                    optionInput.maxLength = '20';
                    optionInput.placeholder = 'Input Option';
                    optionInput.classList.add('form-control');

                    const optionInputGroupAppend = document.createElement('div');
                    optionInputGroupAppend.classList.add('input-group-append');

                    const removeOptionButton = document.createElement('button');
                    removeOptionButton.type = 'button';
                    removeOptionButton.classList.add('btn', 'btn-outline-danger');
                    removeOptionButton.textContent = '−';
                    removeOptionButton.addEventListener('click', function() {
                        optionsContainer.removeChild(optionGroup);
                    });

                    optionInputGroupAppend.appendChild(removeOptionButton);

                    optionGroup.appendChild(optionInput);
                    optionGroup.appendChild(optionInputGroupAppend);

                    optionsContainer.appendChild(optionGroup);
                } else {
                    alert('Maksimum 20 pilihan.');
                }
            }


        });

        $(document).ready(function() {
            var deleteProductBaseUrl = "{{ url('deleteproduct') }}";
            $('#searchInput').keyup(function() {
                var query = $(this).val();
                $.ajax({
                    url: '/search-sku',
                    type: 'GET',
                    data: {
                        query: query
                    },
                    success: function(data) {
                        if (data.length === 0) {
                            var noDataHtml = `<tr>
                    <td colspan="7" class="text-center">
                        <div class="card mb-3">
                            <div class="card-body">
                                <img class="img-fluid px-3 px-sm-4 mt-3 mb-4" style="width: 10rem;" src="/storage/images/1705557639_nodata.jpg" alt="No Data Available">
                                <h5>There is no Product yet</h5>
                                <p>Let's create your Product.</p>
                                <a class="btn btn-warning btn-icon-split" data-toggle="modal" data-target="#addModal">
                                    <span class="icon text-white-50">
                                        <i class="fas fa-plus"></i>
                                    </span>
                                    <span class="text">Add Product</span>
                                </a>
                            </div>
                        </div>
                    </td>
                </tr>`;
                            $('#searchResults').html(noDataHtml);
                        } else {
                            var html = '';
                           $.each(data, function(index, product) {
                                var storeInfo = product.store ? `${product.store.shop_name || 'Unknown Shop'} - ${product.store.driver || 'Unknown Driver'}` : '<span>No shops available</span>';
                                var images = typeof product.image === 'string' ? JSON.parse(product.image) : product.image;
                                var imageHtml = images && images.length > 0 ? `<img src="${images[0]}" alt="Main Photo" style="width: 50px; height: auto;">` : 'No Photo';

                                // Access the mapping count directly from the product object
                                var mappedCount = product.mappings_count;

                                html += `<tr>
                                            <td class="text-center">
                                                <input type="checkbox" name="checked_items[]" class="checkItem large-checkbox" style="transform: scale(1.5);" value="${product.id}">
                                            </td>
                                            <td>${imageHtml}</td>
                                            <td>${product.name}</td>
                                            <td class="col-md-3">${storeInfo}</td>
                                            <td>${product.sku}</td>
                                            <td>${product.stock}</td>
                                            <td><a href="#" data-toggle="modal" data-target="#productMappingModal" data-product-id="${product.id}">${mappedCount}</a></td>
                                            <td>
                                                <div class="dropdown">
                                                    <button class="btn btn-outline-warning dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                                                        Action
                                                    </button>
                                                    <div class="dropdown-menu">
                                                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#updateModal${product.id}">
                                                            <i class="fas fa-edit"></i> Edit
                                                        </a>
                                                        <a class="dropdown-item" href="#"><i class="fas fa-arrow-up"></i> Upload To Marketplace</a>
                                                        <form action="/deleteproduct/${product.id}" method="POST">
                                                            <input type="hidden" name="_token" value="${$('meta[name="csrf-token"]').attr('content')}">
                                                            <button class="dropdown-item" type="submit" onclick="return confirm('Are you sure you want to delete this record?')">
                                                                <i class="fas fa-trash"></i> Delete
                                                            </button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>`;
                            });

             

                                
                           
                            $('#searchResults').html(html);
                        }
                    },
                    error: function(request, status, error) {
                        $('#searchResults').html('<p>An error occurred while searching.</p>');
                    }
                });
            });



            // Fungsi untuk menangani pencarian product
            $('#searchInputbundling').keyup(function() {
                var query = $(this).val();
                if (query.length < 3) { // You may want to start searching after 2 or more characters
                    return; // Stop the function if the query is too short.
                }
                $.ajax({
                    url: '/search-products',
                    type: 'GET',
                    data: {
                        query: query
                    },
                    success: function(data) {
                        // Check if new data is actually present
                        if (data.length > 0) {
                            var html = '';
                            $.each(data, function(index, product) {
                                // Ensure the product isn't already added
                                if ($('#productbundling-table td:contains(' + product.sku + ')').length === 0) {
                                    html += `<tr>
                            <td>${product.name}</td>
                            <td>${product.sku}</td>
                            <td>${product.cost_of_goods}</td>
                            <td>${product.consumer_price}</td>
                            <td>
                                <div class="col-md-4">
                                    <input type="hidden" name="product_id[]" value="${product.id}">
                                    <input type="number" name="qty[]" class="form-control">
                                </div>
                            </td>
                            <td>
                                <button type="button" class="remove-product btn btn-danger btn-sm">
                                    <i class="fas fa fa-trash"></i>
                                </button>
                            </td>

                        </tr>`;
                                }
                            });
                            // Append the new HTML to the existing results
                            $('#searchResultsbundling').append(html);
                        }
                    },
                    error: function(request, status, error) {
                        $('#searchResultsbundling').html('<p>Error fetching search results.</p>');
                    }
                });
            });
            $('#searchResultsbundling').on('click', '.remove-product', function() {
                $(this).closest('tr').remove();
            });


            $('a[data-toggle="tab"]').on('shown.bs.tab', function(e) {
                var target = $(e.target).attr("href"); // activated tab
                $(target).addClass('show');
            });

            // nav upload file
            $('.nav-link').click(function() {
                // Remove active class from all tabs
                $('.nav-link').removeClass('active');
                $('.tab-pane').removeClass('show active');

                // Add active class to clicked tab
                $(this).addClass('active');
                var tabTarget = $(this).attr('href');
                $(tabTarget).addClass('show active');

                // Prevent default anchor behavior
                return false;
            });

            $('.nav-link-edit').click(function() {
                // Remove active class from all tabs
                $('.nav-link-edit').removeClass('active');
                $('.tab-pane-edit').removeClass('show active');

                // Add active class to clicked tab
                $(this).addClass('active');
                var tabTarget = $(this).attr('href');
                $(tabTarget).addClass('show active');

                // Prevent default anchor behavior
                return false;
            });
        });
    </script>

    <script src="//cdn.jsdelivr.net/npm/eruda"></script>
    <script>
        eruda.init();
    </script>
    @endsection