<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!-- jQuery with CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <title>Fulhive</title>
    <!-- Custom styles for this template-->
    <link href="{{ asset('asset/css/sb-admin-2.min.css') }}" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">

    <style>
        .bg-primary {
            background-color: #FF5722 !important;
            /* Bootstrap primary color */
        }

        .container {
            min-height: 100vh;
            /* Full height */
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .card {
            max-width: 400px;
            text-align: center;
            background-color: #fff;
            /* White background */
        }

        .card-img-top {
            height: 200px;
            /* Adjust as needed */
            background: url('path_to_your_image.jpg') no-repeat center center;
            background-size: cover;
        }

        .card-title,
        .card-text {
            color: #000;
            /* Black text for better readability */
        }
    </style>
</head>

<body class="bg-primary">
    <div class="container">
        <div class="card">

            <div class="card-body">
                <div class="justify-content-center mt-4 mb-2">
                    <img src="{{ asset('asset/img/fulhive-logo-black.png') }}" width="300">
                </div>
                <h5 class="card-title">Okay, Success</h5>
                <p class="card-text">Shop authorization process is successful. Please return to </p>

                <h6><a href="{{ route('marketplace')}}" class="text-decoration-none">Fulhive</a></h6>

            </div>
        </div>
    </div>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.bundle.min.js" integrity="sha384-oesi62hoyf6xcjv8eafW3sNVNWp4d0I4x2b40q97uCQf3js28i54tOlSBO9dKutN" crossorigin="anonymous"></script>
</body>

</html>
