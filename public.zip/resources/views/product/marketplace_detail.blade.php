<style>
    .photo-upload-container {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
    }

    .photo-upload-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        /* Atur jarak antar elemen */
    }

    .photo-upload-box {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        border: 2px dashed #00b4d8;
        border-radius: 10px;
        width: 100px;
        /* Atur lebar box */
        height: 100px;
        /* Atur tinggi box */
    }

    .photo-upload-input {
        display: none;
        /* Sembunyikan input file asli */
    }

    .photo-upload-label {
        cursor: pointer;
        text-align: center;
    }
</style>
@extends('layouts.master')

@section('content')
<div class="container-fluid">
    @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif

    @if(session('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert" id="success-alert">
        {{ session('success') }}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    @endif

    @if(session('error'))
    <div class="alert alert-danger alert-dismissible fade show" role="alert" id="danger-alert">
        {{ session('error') }}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    @endif

    <div class="row justify-content-between">
        <div class="col-md-4">
            <h6 class="h3 text-gray-800 ml-3">Marketplace Detail</h6>
            <div class="row ml-3 mb-2">
                <a href="{{ route('marketplace') }}">Marketplace /</a> &nbsp;
                <div class="small-text"> Marketplace Detail</div>
            </div>
        </div>
        <!-- <div class="text-right mr-4">
            <button class="btn btn-primary" data-toggle="modal" data-target="#addStoreModal">Add Store</button>
        </div> -->
    </div>
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="card shadow mb-4 ml-4 mt-4">
                    <div class="card-body">
                        <h3>{{$store->shop_name}}</h3>
                        <div class="d-flex justify-content-end">
                            <p>Last Updated : {{$store->updated_at}}</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <ul class="nav nav-tabs mb-4 justify-content-between" id="myTab" role="tablist">
            <li class="nav-item">
                <a class="nav-link active text-center" id="live-tab" data-toggle="tab" href="#live" role="tab" aria-controls="live" aria-selected="false">Live</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-center" id="hidden-tab" data-toggle="tab" href="#hidden" role="tab" aria-controls="hidden" aria-selected="false">Hidden</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-center" id="draft-tab" data-toggle="tab" href="#draft" role="tab" aria-controls="draft" aria-selected="false">Draft</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-center" id="uploaded-tab" data-toggle="tab" href="#uploaded" role="tab" aria-controls="uploaded" aria-selected="false">Uploading</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-center" id="failed-to-display-tab" data-toggle="tab" href="#failed-to-display" role="tab" aria-controls="failed-to-display" aria-selected="false">Failed To Display</a>
            </li>
        </ul>
        <!--<div class="row ml-2 mb-4">-->
        <!--    <div class="col-md-2">-->
        <!--        <div class="dropdown">-->
        <!--            <button class="btn btn-outline-primary dropdown-toggle btn-block" type="button" data-toggle="dropdown" aria-expanded="false">-->
        <!--                Sort-->
        <!--            </button>-->
        <!--            <div class="dropdown-menu">-->
        <!--                <a class="dropdown-item" href="#">Action</a>-->
        <!--                <a class="dropdown-item" href="#">Another action</a>-->
        <!--                <a class="dropdown-item" href="#">Something else here</a>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--    <div class="col-md-2">-->
        <!--        <div class="dropdown">-->
        <!--            <button class="btn btn-outline-secondary dropdown-toggle btn-block" type="button" data-toggle="dropdown" aria-expanded="false">-->
        <!--                Status-->
        <!--            </button>-->
        <!--            <div class="dropdown-menu">-->
        <!--                <a class="dropdown-item" href="#">Action</a>-->
        <!--                <a class="dropdown-item" href="#">Another action</a>-->
        <!--                <a class="dropdown-item" href="#">Something else here</a>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--    <div class="col-md-2">-->
        <!--        <button class="btn btn-primary btn-block">Reset</button>-->
        <!--    </div>-->
        <!--</div>-->
        <div class="tab-content col-md-12 mt-4">
            <div class="tab-pane fade show active" id="live" role="tabpanel" aria-labelledby="live-tab">
                <table id="example" class="table table-borderless table-striped" style="width:100%">
                    <thead>
                        <tr>
                            <th><input type="checkbox" id="selectAll" onclick="headerCheckboxChecked(this);" class="large-checkbox" style="transform: scale(1.5);"></th>
                            <th>Product</th>
                            <!--<th>Marketplace Price</th>-->
                            <th>Weight</th>
                            <th>Mapping Status</th>
                            <!--<th>Time</th>-->
                            <!--<th>Action</th>-->
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($products as $product )

                        <tr>
                            <td><input type="checkbox" name="checked_items[]" value="{{ $product->id }}" class="checkItem large-checkbox" style="transform: scale(1.5);"></td>
                            <td>
                                <a href="#detailModal{{ $product->id }}" data-toggle="modal" data-target="#detailModal{{ $product->id }}">{{ $product->name }}</a>
                            </td>

                            <td>{{ $product->weight }}</td>
                            <td>
                                @if($product->mappings->contains('product_id', $product->id))
                                <strong class="text-warning">Mapped</strong>
                                @else
                                <strong class="text-secondary">Not Mapped</strong>
                                @endif
                            </td>

                            <!--<td></td>-->
                            <!--<td>-->
                            <!--    <form action="{{ route('deletemarketplace', $store->id) }}" method="POST">-->
                            <!--        @csrf-->
                            <!--        <button class="btn btn-outline-danger" href="#" type="submit" onclick="return confirm('Are you sure you want to delete this record?')"><i class="fas fa-regular fa-trash"></i></button>-->
                            <!--    </form>-->
                            <!--</td>-->
                        </tr>


                        <!-- Modal -->
                        <div class="modal fade" id="detailModal{{ $product->id }}" tabindex="-1" role="dialog" aria-labelledby="modalLabel{{ $product->id }}" aria-hidden="true">
                            <div class="modal-dialog modal-lg" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="modalLabel{{ $product->id }}">{{ $product->name }}</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="card">
                                            <div class="card-header">Basic Information</div>
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <label for="name" class="col-form-label">Product Name</label>
                                                    <input type="text" class="form-control" disabled name="name" value="{{ $product->name}}">
                                                </div>
                                                <div class="form-group">
                                                    <label for="sku" class="col-form-label">Product Sku</label>
                                                    <input type="text" class="form-control" disabled name="sku" value="{{ $product->sku}}">
                                                </div>
                                                <div class="form-group">
                                                    <label for="message-text" class="col-form-label">Description</label>
                                                    <textarea class="form-control" id="message-text" cols="40" name="description" disabled>{{ $product->description }}</textarea>
                                                </div>
                                                <div class="form-row">
                                                    <div class="form-group col-lg-12">
                                                        <label for="weight" class="col-form-label">Weight</label>
                                                        <div class="input-group">
                                                            <input type="text" class="form-control" disabled name="weight" aria-describedby="basic-addon2" value="{{ $product->weight}}">
                                                            <div class="input-group-append">
                                                                <span class="input-group-text" id="basic-addon2">Gram</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="size" class="col-form-label">Size</label>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="input-group">
                                                                <input type="text" class="form-control" disabled name="size" aria-describedby="basic-addon1" value="{{ $product->size}}">
                                                                <div class="input-group-append">
                                                                    <span class="input-group-text" id="basic-addon1">Cm</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="input-group">
                                                                <div class="input-group">
                                                                    <input type="text" class="form-control" disabled name="width" aria-describedby="basic-addon2" value="{{ $product->width}}">
                                                                    <div class="input-group-append">
                                                                        <span class="input-group-text" id="basic-addon2">Cm</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="input-group">
                                                                <div class="input-group">
                                                                    <input type="text" class="form-control" disabled name="high" aria-describedby="basic-addon2" value="{{ $product->height}}">
                                                                    <div class=" input-group-append">
                                                                        <span class="input-group-text" id="basic-addon2">Cm</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        @include('partials._photo_upload_form_update')
                                    </div>
                                </div>
                            </div>


                            @endforeach
                    </tbody>
                </table>
                <div class="d-flex justify-content-end mt-4">

                    {!! $products->links() !!}
                </div>
            </div>
            <div class="tab-pane fade" id="hidden" role="tabpanel" aria-labelledby="hidden-tab">
            </div>
            <div class="tab-pane fade" id="draft" role="tabpanel" aria-labelledby="draft-tab">
            </div>
            <div class="tab-pane fade" id="uploaded" role="tabpanel" aria-labelledby="uploaded-tab">
            </div>
            <div class="tab-pane fade" id="failed-to-display" role="tabpanel" aria-labelledby="failed-to-display-tab">
            </div>
        </div>
    </div>
    <!-- end card tim saya -->
</div>

<script>
    function headerCheckboxChecked(source) {
        // Get all checkboxes with the class 'checkItem'
        var checkboxes = document.querySelectorAll('.checkItem');

        // Loop through each checkbox and change the checked state to match the header checkbox
        checkboxes.forEach(function(checkbox) {
            checkbox.checked = source.checked;
        });
    }

    // Function to get the values of all checked checkboxes
    function getCheckedValues() {
        var checkedValues = [];
        var checkboxes = document.querySelectorAll('.checkItem:checked');

        // Add the value of each checked checkbox to the array
        checkboxes.forEach(function(checkbox) {
            checkedValues.push(checkbox.value);
        });

        // Log the array to the console or process as needed
        console.log(checkedValues);
        return checkedValues;
    }

    function previewImage(event, index) {
        if (event.target.files && event.target.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                var output = document.getElementById('preview' + index);
                output.src = e.target.result;
                output.style.display = 'block'; // Show the image
            };
            reader.readAsDataURL(event.target.files[0]);
        }
    }
</script>

@endsection