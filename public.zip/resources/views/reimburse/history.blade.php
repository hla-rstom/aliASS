<style>
    .container {
        background-color: #f0f4f7;
        padding: 20px;
    }

    .card {
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border: none;
    }

    .btn-warning {
        background-color: #f0ad4e;
        border: none;

    }

    .btn-warning:hover {
        background-color: #ec971f;

    }
</style>
@extends('layouts.master')

@section('content')
<div class="container-fluid">
    @include('partials._alert')
    <div class="card shadow mb-4">
        <div class="card-header py-3 mb-4">
            <div class="row ml-2">
                <a href="{{ url()->previous() }}"><i class="fas fa-solid fa-chevron-left"></i> Back</a> &nbsp;
                <div class="small-text"> </div>
                
            </div>
            <div class="card mt-4 mb-4">
                <div class="card-body">
                    <h6><strong>Reimburse History</strong></h6>
                    <table id="example" class="table table-borderless mt-4" style="width:100%">
                        <thead class="thead-light">
                            <tr>
                                <th>Date</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Description</th>
                                @if (auth()->user()->as_a == 'seller')
                                    <th>Action</th>
                                @endif
                            </tr>
                        </thead>
                        <tbody>
                            @if (!empty ($reimburses))
                            @foreach ($reimburses as $reimburse)
                            <tr>
                                <td>{{ $reimburse->created_at->format('d M Y') }}</td>
                                <td>{{$reimburse->amount}}</td>
                                <td>{{$reimburse->status}}</td>
                                <td>{{$reimburse->description}}</td>
                                 @if (auth()->user()->as_a == 'seller' && $reimburse->status == 'pending')
                                    <td>
                                        <form action="{{ route('reimburses.approve', $reimburse->id) }}" method="POST">
                                            @csrf
                                            
                                            <button type="submit" class="btn btn-warning">Approve</button>
                                        </form>
                                    </td>
                                @endif
                            </tr>
                            @endforeach
                            @endif
                        </tbody>
                    </table>

@endsection
