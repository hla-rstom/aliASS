@extends('layouts.master')

@section('content')
<div class="container-fluid">
    @include('partials._alert')

    <div class="row justify-content-between">
        <h6 class="h3 mb-3 text-gray-800 ml-3">Packaging</h6>
        <div class="text-right">
            <a class="btn btn-warning btn-icon-split" data-toggle="modal" data-target="#exampleModal">
                <span class="icon text-white-50">
                    <i class="fas fa-plus"></i>
                </span>
                <span class="text">Add Template</span>
            </a>
        </div>
    </div>
    <div class="row">
        <!-- First Card -->
        <div class="col-md-12">
            <div class="card mb-3 alert-warning">
                <div class="card-body">
                    <h5 class="card-title"><i class="fas fa-solid fa-info mr-2"></i>Informasi</h5>
                    <p class="card-text">You can apply this feature to apply the same type of packaging material for each product. This feature is recommended for products that are sold frequently.</p>
                </div>
            </div>
        </div>

        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Create Packaging Template</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="modal-body">
                            <div class="card mb-3 alert-warning">
                                <div class="card-body">
                                    <h5 class="card-title"><i class="fas fa-solid fa-info mr-2"></i>Informasi</h5>
                                    <p class="card-text">You can apply this feature to apply the same type of packaging material for each product. This feature is recommended for products that are sold frequently.</p>
                                </div>
                            </div>
                            <form action="{{ route('packagingtemplatestore') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="mb-3">
                                    <label class="small mb-1" for="name">Name <span class="text-danger">*</span></label>
                                    <input class="form-control @error('name') is-invalid @enderror" id="name" name="name" type="text" placeholder="" value="{{ old('name') }}" />
                                    @error('name')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                                <div id="materialPackagingList">
                                    <!-- Material Packaging Input Group -->
                                    <div class="input-group mb-3">
                                        <select class="custom-select" name="packaging_id[]">
                                            <option selected>Choose Material Packaging</option>
                                            @foreach ($packaging as $pack)
                                            <option value="{{$pack->id}}">{{$pack->name}}</option>
                                            @endforeach
                                        </select>
                                        <input type="number" class="form-control" name="qty[]" placeholder="Qty">
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-danger remove-material" type="button"><i class="fas fa-trash-alt"></i></button>
                                        </div>
                                    </div>
                                    <!-- Clone this div for new material packaging inputs -->
                                </div>
                                <div class="text-center">
                                    <button id="addMaterialPackaging" type="button" class="btn btn-warning mb-4">+ Add Material Packaging</button>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-warning">Save changes</button>
                                </div>
                            </form>
                        </div>

                        <!-- ... rest of the code ... -->

                    </div>
                </div>
            </div>
        </div>
        <!-- Second Card (Placeholder for another similar card) -->
        <div class="col-md-12">
            @if($packagingtemps->isNotEmpty())
            <table id="example" class="table table-borderless" style="width:100%">
                <thead class="thead-light">
                    <tr>
                        <th>No</th>
                        <th>Packaging Template Name</th>
                        <th>Packaging Matrial</th>
                        <th>Qty</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($packagingtemps as $index => $template)
                    @php
                    $rowCount = count($template->materials); // Get the count for rowspan
                    @endphp
                    @foreach ($template->materials as $materialIndex => $material)
                    <tr>
                        {{-- Render the template name and number only once per template --}}
                        @if ($materialIndex === 0)
                        <td rowspan="{{ $rowCount }}">{{ $index + 1 }}</td>
                        <td rowspan="{{ $rowCount }}">{{ $template->name }}</td>
                        @endif
                        {{-- Material and Quantity --}}
                        <td>{{ $material->packaging->name ?? '' }}</td>
                        <td>{{ $material->qty }}</td>
                        {{-- Render the action buttons only once per template --}}
                        @if ($materialIndex === 0)
                        <td rowspan="{{ $rowCount }}">
                            <form action="{{ route('packagingtemplatedestroy', $template->id) }}" method="POST">
                                @csrf
                                @method('delete')
                                <button type="submit" class="btn btn-outline-danger" onclick="return confirm('Are you sure you want to delete this record?')"><i class="fas fa-solid fa-trash"></i></button>
                            </form>
                        </td>
                        @endif
                    </tr>
                    @endforeach
                    @endforeach

                </tbody>
            </table>
            @else
            <div class="card mb-3">
                <div class="card-body text-center">
                    <img class="img-fluid px-3 px-sm-4 mt-3 mb-4" style="width: 25rem;" src="{{ asset('storage/images/1705557639_nodata.jpg') }}" alt="...">
                    <h5 class="card-title">There is no packaging template yet</h5>
                    <p class="card-text">Let's create your Packaging Template.</p>
                    <a class="btn btn-warning btn-icon-split" data-toggle="modal" data-target="#exampleModal">
                        <span class="icon text-white-50">
                            <i class="fas fa-plus"></i>
                        </span>
                        <span class="text">Add Template</span>
                    </a>
                </div>
            </div>
            @endif
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // Function to add new material packaging input
        $('#addMaterialPackaging').click(function() {
            var newInputGroup = $('#materialPackagingList .input-group:first').clone();
            newInputGroup.find('select').val(""); // Resets select input
            newInputGroup.find('input').val(""); // Resets quantity input
            $('#materialPackagingList').append(newInputGroup);
        });

        // Event delegation for dynamically added remove buttons
        $('#materialPackagingList').on('click', '.remove-material', function() {
            if ($('#materialPackagingList .input-group').length > 1) {
                $(this).closest('.input-group').remove();
            } else {
                alert('You must have at least one material packaging input.');
            }
        });
    });
</script>
@endsection