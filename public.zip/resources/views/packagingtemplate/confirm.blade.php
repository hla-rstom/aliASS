@extends('layouts.master')

@section('content')
<div class="container-fluid">
    @include('partials._alert')

    <div class="row justify-content-between">
        <h6 class="h3 mb-3 text-gray-800 ml-3">Confirm Packaging</h6>

    </div>
    <div class="row">
        <div class="col-md-12">
            @if($packagingTransactions->isNotEmpty())
            <table id="example" class="table table-borderless" style="width:100%">
                <thead class="thead-light">
                    <tr>
                        <th>Invoice Code</th>
                        <th>Packaging Template Name</th>
                        <th>Packaging Item</th>
                        <th>Qty</th>
                        <th>Price</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($packagingTransactions as $templateName => $transactions)
                    @if($templateName !== 'single')
                    @php
                    $totalQty = $transactions->sum('qty');
                    $totalPrice = $transactions->sum(function($transaction) {
                    return $transaction->qty * $transaction->packaging->price;
                    });
                    @endphp
                    <tr>
                        <td>{{$transactions->first()->transaction->invoice_code}}</td>
                        <td rowspan="{{ count($transactions) + 1 }}">
                            {{ $templateName }}
                        </td>
                        <td>{{ $transactions->first()->packaging->name }}</td>
                        <td>{{ $transactions->first()->qty }}</td>
                        <td>{{ number_format($transactions->first()->packaging->price, 2) }}</td>
                        <td>{{ number_format($transactions->first()->qty * $transactions->first()->packaging->price, 2) }}</td>
                        <td rowspan="{{ count($transactions) + 1 }}">
                            @if($transactions->first()->status === 'Pending')
                            <button type="button" class="btn btn-sm btn-warning" data-toggle="modal" data-target="#confirmModal" data-id="{{ $transactions->first()->transaction->id }}">
                                Approve
                            </button>
                            @endif
                        </td>
                    </tr>
                    @foreach($transactions->slice(1) as $transaction)
                    <tr>
                        <td></td>
                        <td>{{ $transaction->packaging->name }}</td>
                        <td>{{ $transaction->qty }}</td>
                        <td>{{ number_format($transaction->packaging->price, 2) }}</td>
                        <td>{{ number_format($transaction->qty * $transaction->packaging->price, 2) }}</td>
                    </tr>
                    @endforeach
                    <tr>
                        <td colspan="4" class="text-right"><strong>Total</strong></td>
                        <td><b>({{ $totalQty }})</b> - <span class="text-warning"><b>{{ number_format($totalPrice, 2) }}</b></span></td>
                        <td></td>
                        <td></td>
                    </tr>
                    @else
                    @foreach($transactions as $transaction)
                    <tr>
                        <td>{{$transactions->first()->transaction->invoice_code}}</td>
                        <td>Default Packaging</td>
                        <td>{{ $transaction->packaging->name }}</td>
                        <td>{{ $transaction->qty }}</td>
                        <td>{{ number_format($transaction->packaging->price, 2) }}</td>
                        <td>{{ number_format($transaction->qty * $transaction->packaging->price, 2) }}</td>
                        <td>
                            @if($transaction->status === 'Pending')
                            <button type="button" class="btn btn-sm btn-warning" data-toggle="modal" data-target="#confirmModal" data-id="{{ $transaction->transaction->id }}">
                                Approve
                            </button>
                            @endif
                        </td>
                    </tr>
                    @endforeach
                    @endif
                    @endforeach
                </tbody>
            </table>
            @else
            <div class="card mb-3">
                <div class="card-body text-center">
                    <img class="img-fluid px-3 px-sm-4 mt-3 mb-4" style="width: 25rem;" src="{{ asset('storage/images/1705557639_nodata.jpg') }}" alt="No data available">
                    <h5 class="card-title">There is no packaging confirm yet</h5>
                </div>
            </div>
            @endif
        </div>

    </div>
</div>

<!-- Modal Structure -->
<div class="modal fade" id="confirmModal" tabindex="-1" role="dialog" aria-labelledby="confirmModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmModalLabel">Confirm Packaging Fee</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="alert-warning">
                    You will confirm the packaging fee used in the order and reduce your wallet.
                </div>
                <form id="confirmForm" method="POST" action="{{ route('confirmfee') }}">
                    @csrf
                    <input type="hidden" name="id" id="modalPackagingId">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-warning">Confirm</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#confirmModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget); // Button that triggered the modal
            var packagingId = button.data('id'); // Extract info from data-* attributes
            var modal = $(this);
            modal.find('#modalPackagingId').val(packagingId); // Update the modal's content
        });
    });
</script>
@endsection