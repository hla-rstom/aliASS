<style>
    #profilePhoto {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        object-fit: cover;
    }

    .list-group-item-action {
        display: flex;
        flex-direction: column;
        /* Stack items vertically */
        align-items: center;
        /* Center-align items horizontally */
        text-align: center;
        /* Ensure text labels are centered below images */
        gap: 5px;
        /* Adjust the space between the image and the text */
        max-width: 120px;
        border: none
    }

    .list-group.d-flex {
        flex-wrap: nowrap;
        /* Prevents wrapping of items to ensure inline display */
        overflow-x: auto;
        /* Adds horizontal scroll on small screens */
    }
</style>
@extends('layouts.master')

@section('content')
<div class="container-fluid">
    @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif

    @if(session('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert" id="success-alert">
        {{ session('success') }}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    @endif
    <h6 class="h3 mb-3 text-gray-800 ml-3">Store Information</h6>
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="row">
                    <!-- <div class="col-lg-3">
                        <div class="card mb-4">
                            <div class="card-body text-center">
                                @if(isset($shop->photo))

                                <img id="profilePhoto" src="{{ asset('storage/'. $shop->photo) }}" class="card-img-top rounded-circle mx-auto d-block" alt="Profile Photo">
                                @endif
                                <form action="{{ route('uploadphoto') }}" method="POST" enctype="multipart/form-data">
                                    @csrf
                                    <label for="photoInput" class="btn btn-outline-primary mb-4 mt-4">Choose Photo</label>
                                    <input type="file" id="photoInput" name="photo" style="display: none;" onchange="previewImage()">
                                    <button type="submit" class="btn btn-primary mb-4 mt-4">Add Photo</button>
                                </form>
                            </div>

                        </div>
                    </div>

                    <div class="col-lg-9">
                        <div class="card mb-4">
                            <div class="card-body">
                                <div class="card-header py-3 mb-4">
                                    <h6 class="m-0 font-weight-bold text-gray-700">Information</h6>
                                </div>
                                <form class="ml-3">
                                    @if($shop)
                                    <div class="row">
                                        <div class="col-lg-5 mr-4">
                                            <div class="form-group">
                                                <label>Name</label>
                                                <input type="text" class="form-control" value="{{ $shop->shop_name}}">
                                            </div>
                                        </div>
                                        <div class="col-lg-5 mr-4">
                                            <div class="form-group">
                                                <label>Area</label>
                                                <input type="text" class="form-control" value="{{$shop->area}}">
                                            </div>
                                        </div>
                                    </div>
                                    @endif
                                    @if($shop)
                                    <div class="row">
                                        <div class="col-lg-5 mr-4">
                                            <div class="form-group">
                                                <label>Address</label>
                                                <textarea class="form-control" cols="60" rows="5"> {{$shop->address}} </textarea>
                                            </div>
                                        </div>
                                    </div>
                                    @endif
                                </form>
                            </div>
                        </div>
                    </div> -->
                </div>
            </div>
            <div class="row">
                <div class="col-lg-11 ml-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="card-header py-3 mb-4">
                                <h6 class="m-0 font-weight-bold text-gray-700">Your Store Marketplace</h6>
                            </div>
                            <div class="col-lg-11">
                                <!-- <div class="mb-4">
                                    <button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#addModal"><i class="fas fa-solid fa-plus"></i> Add Store</button>
                                </div> -->
                                <!-- Modal Add Shop -->
                                <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="addModalLabel">Add Link Store</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="{{ route('storeshop') }}" method="POST" enctype="multipart/form-data" class="ml-3">
                                                    @csrf
                                                    <div class="form-group">
                                                        <label for="name" class="col-form-label">Name</label>
                                                        <input type="text" class="form-control" name="shop_name">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="sku" class="col-form-label">Marketplace</label>
                                                        <select class="form-control" name="driver">
                                                            <option>-- marketplace --</option>
                                                            <option value="shopee">SHOPEE</option>
                                                            <option value="tiktok">TIKTOK</option>
                                                            <option value="lazada">LAZADA</option>
                                                            <option value="woocommers">WOO COMMERS</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="sku" class="col-form-label">Link</label>
                                                        <input type="text" class="form-control" name="link">
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">Submit</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End modal -->
                                <table class="table">
                                    @if($shops->isNotEmpty())
                                    <thead class="thead-light">
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Marketplace</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($shops as $shop )
                                        <tr>
                                            <th scope="row">{{ $loop->iteration}}</th>
                                            <td>{{ $shop->shop_name}}</td>
                                            <td>{{ $shop->driver}}</td>
                                            <!-- <td><i class="fas fa-solid fa-edit" data-toggle="modal" data-target="#editModal"></td> -->
                                            <!-- Modal Edit Shop -->
                                            <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="addModalLabel">Add Link Store</h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form action="{{ route('updateshop', $shop->id) }}" method="POST" enctype="multipart/form-data" class="ml-3">
                                                                @csrf
                                                                @method('put')
                                                                <div class="form-group">
                                                                    <label for="name" class="col-form-label">Name</label>
                                                                    <input type="text" class="form-control" name="name" value="{{ $shop->name}}">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="driver" class="col-form-label">Marketplace</label>
                                                                    <select class="form-control" name="driver" id="driver">
                                                                        <option value="" disabled>-- Select Marketplace --</option>
                                                                        <option value="shopee" {{ $shop->driver == 'shopee' ? 'selected' : '' }}>SHOPEE</option>
                                                                        <option value="tiktok" {{ $shop->driver == 'tiktok' ? 'selected' : '' }}>TIKTOK</option>
                                                                        <option value="lazada" {{ $shop->driver == 'lazada' ? 'selected' : '' }}>LAZADA</option>
                                                                        <option value="woocommers" {{ $shop->driver == 'woocommers' ? 'selected' : '' }}>WOO COMMERS</option>
                                                                    </select>
                                                                </div>

                                                                <div class="form-group">
                                                                    <label for="sku" class="col-form-label">Link</label>
                                                                    <input type="text" class="form-control" name="link" value="{{ $shop->link}}">
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-primary">Submit</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- End modal -->
                                        </tr>
                                        @endforeach
                                        @else

                                        <div class="card mb-3">
                                            <div class="card-body text-center">
                                                <img class="img-fluid px-3 px-sm-4 mt-3 mb-4" style="width: 25rem;" src="{{ asset('storage/images/1705557639_nodata.jpg') }}" alt="...">
                                                <h5 class="card-title">There is no Marketplace yet</h5>
                                                <p class="card-text">Let's add your Marketplace.</p>
                                                <a class="btn btn-primary btn-icon-split" data-toggle="modal" data-target="#addStoreModal">
                                                    <span class="icon text-white-50">
                                                        <i class="fas fa-plus"></i>
                                                    </span>
                                                    <span class="text">Add Store</span>
                                                </a>
                                            </div>
                                        </div>
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-11 ml-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="card-header py-3 mb-4">
                                <div class="container mt-4">
                                    @if($shops->isEmpty())
                                    <!-- No shops available -->
                                    <div class="alert alert-info" role="alert">
                                        No shops available. <a href="{{ route('marketplace') }}" class="alert-link">Add a new shop</a> to get started.
                                    </div>
                                    @else
                                    <h6>Please sync addresses added to your marketplace store and then set a default address to ship from here. Make sure it is the Warehouse address.</h6>

                                    @foreach ($shops as $shop)
                                    <div class="row align-items-center mb-3">
                                        <div class="col-md-4">
                                            <strong>{{ $shop->shop_name }}</strong>
                                        </div>
                                        <div class="col-md-4">
                                            <form action="{{ route('addresssync') }}" method="POST">
                                                @csrf
                                                <input type="hidden" name="token" value="{{ $shop->access_token }}">
                                                <input type="hidden" name="shop_id" value="{{ $shop->id }}">
                                                <input type="hidden" name="type" value="shopee">
                                                <button type="submit" class="btn btn-primary">Sync Address</button>
                                            </form>
                                        </div>
                                        <div class="col-md-4">
                                            <select class="form-control default-address-select" data-shop-id="{{ $shop->shop_id }}">
                                                @foreach ($shop->addresses as $address)
                                                <option value="{{ $address->id }}" {{ $address->default ? 'selected' : '' }}>
                                                    {{ $address->address }}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>


                                    </div>
                                    @endforeach

                                    @endif
                                </div>


                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Store Modal -->
<div class="modal fade" id="addStoreModal" tabindex="-1" role="dialog" aria-labelledby="addStoreModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addStoreModalLabel">Add Store</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="list-group d-flex flex-row justify-content-around align-items-center">
                    <a href="{{route('authorize', 'shopee')}}" class="list-group-item list-group-item-action d-flex flex-column align-items-center">
                        <img src="{{asset('asset/img/shopee.png')}}" alt="Shopee" width="50">
                        <span>Shopee</span>
                    </a>
                    <a href="{{route('authorize', 'tiktok')}}" class="list-group-item list-group-item-action d-flex flex-column align-items-center">
                        <img src="{{asset('asset/img/tiktok.png')}}" alt="TikTok" width="50">
                        <span>TikTok</span>
                    </a>
                    <a href="{{route('authorize', 'lazada')}}" class="list-group-item list-group-item-action d-flex flex-column align-items-center">
                        <img src="{{asset('asset/img/lazada.png')}}" alt="Lazada" width="50">
                        <span>Lazada</span>
                    </a>
                    <a href="{{route('authorize', 'woocommerce')}}" class="list-group-item list-group-item-action d-flex flex-column align-items-center">
                        <img src="{{asset('asset/img/woocommerce.png')}}" alt="WooCommerce" width="50">
                        <span>WooCommerce</span>
                    </a>
                </div>
            </div>


        </div>
    </div>
</div>


<script>
    document.getElementById('photoInput').onchange = function() {
        // Misalnya, update teks pada label ketika file dipilih
        document.querySelector('label[for="photoInput"]').textContent = this.files[0].name;
    };

    function submitDefaultForm(element) {
        if (element.checked) {
            element.form.submit();
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        $('.default-address-select').change(function() {
            var selectedAddressId = $(this).val();
            var shopId = $(this).data('shop-id');

            $.ajax({
                url: '{{ route("addressdefault") }}',
                type: 'POST',
                data: {
                    _token: "{{ csrf_token() }}",
                    address_id: selectedAddressId,
                    shop_id: shopId
                },
                success: function(response) {
                    alert('Default address has been updated successfully!');
                },
                error: function() {
                    alert('Failed to update the default address. Please try again.');
                }
            });
        });
    });
</script>

@endsection